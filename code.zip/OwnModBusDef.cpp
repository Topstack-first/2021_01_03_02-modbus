#include "StdAfx.h"
#include "OwnModBusDef.h"

COwnModBusDef::COwnModBusDef(void)
: m_stringDevSeriesName(_T(""))
, m_stringTempTextStore(_T(""))
{
	m_intModBusMasterType = -1;
	m_boolASCMode = FALSE;
	m_boolMaster = FALSE;
	m_boolEthernetType = FALSE;

	m_byteSlaveNum = 0;

	m_lparrayCoils = NULL;
	m_lparrayDiscrets = NULL;
	m_lparrayHolds = NULL;
	m_lparrayInputs = NULL;

	InitRxStateStruct();
	ResetRecvErrorState();
}

COwnModBusDef::~COwnModBusDef(void)
{
	//	Remove Coil Register Info
	if(m_lparrayCoils)
	{
		m_lparrayCoils->RemoveAll();
		delete m_lparrayCoils;
	}
	//	Remove Discrete Input Info
	if(m_lparrayDiscrets)
	{
		m_lparrayDiscrets->RemoveAll();
		delete m_lparrayDiscrets;
	}

	//	Remove Input Register Info
	if(m_lparrayHolds)
	{
		m_lparrayHolds->RemoveAll();
		delete m_lparrayHolds;
	}
	//	Remove Holding Register Info
	if(m_lparrayInputs)
	{
		m_lparrayInputs->RemoveAll();
		delete m_lparrayInputs;
	}

	m_arrayForceErrAddr.RemoveAll();
	m_arrayReadErrAddr.RemoveAll();
}


BYTE COwnModBusDef::SetModBusStationSpecNum(BYTE nNum)
{
	BYTE nPrevNum = m_byteSlaveNum;
	m_byteSlaveNum = nNum;

	return nPrevNum;
}

BYTE COwnModBusDef::GetModBusStationSpecNum(void)
{
	return m_byteSlaveNum;
}

BOOL COwnModBusDef::SetModbusPHYLinkType(BOOL bEthernet)
{
	BOOL bPrevType = m_boolEthernetType;
	m_boolEthernetType = bEthernet;
	return bPrevType;
}

/*===================================================================*
 *	Common Modbus Function
 *		Get CRC Value
 *		Confirm Message Header
 *		Complete Message Type
 *===================================================================*/
WORD COwnModBusDef::GetModBusCRCSumValue(char* lpczMsg, short nMsgLen)
{
	WORD nRetVal = 0xFFFF;
	WORD bBitSetted;

	for(short nId = 0; nId < nMsgLen; nId ++)
	{
		nRetVal ^= ((*lpczMsg ++) & 0xFF);

		for(short nBitId = 0; nBitId < 8; nBitId ++)
		{
			bBitSetted = nRetVal & 0x0001;
			nRetVal >>= 1;

			if(bBitSetted)
				nRetVal ^= 0xA001;
		}
	}

/*	bBitSetted = (nRetVal >> 8) & 0x00FF;
	nRetVal = ((nRetVal << 8) | bBitSetted) & 0xFFFF;	*/
	return nRetVal;
}

void COwnModBusDef::InitRxStateStruct(void)
{
	m_stRxMsgInfo.nTransactionId = 0x00;
	m_stRxMsgInfo.nValue1stId = 0;
	m_stRxMsgInfo.nValueCount = 0;
	m_stRxMsgInfo.nRemainLen = 0;
	m_stRxMsgInfo.nCheckedLen = 0;
	m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_HEADER;

	m_stRxMsgInfo.bBusyFlag = FALSE;
}


MODBUS_REGIST_INFO_ST* COwnModBusDef::GetRegisterInfoPointerFromRegAddr(
	CModBusRegInfoArray* lpRegInfoArray, WORD nRegAddr)
{
	if(lpRegInfoArray == NULL)
		return NULL;

	MODBUS_REGIST_INFO_ST* lpRegInfoPointer = NULL;

	WORD nRegAmount = (WORD)lpRegInfoArray->GetCount();
	WORD nRegLen;
	for(WORD nId = 0; nId < nRegAmount; nId ++)
	{
		MODBUS_REGIST_INFO_ST& stRegisterInfo = lpRegInfoArray->ElementAt(nId);
		nRegLen = (stRegisterInfo.nMsgType < MODBUS_MSG_REAL) ? 1 : 2;
		if((stRegisterInfo.nAddress <= nRegAddr) && ((nRegLen + stRegisterInfo.nAddress) > nRegAddr))
		{
			lpRegInfoPointer = &stRegisterInfo;
			break;
		}
	}
	return lpRegInfoPointer;
}


/*===================================================================*
 *	Extract Data From Modbus Message
 *		Get CRC Value
 *		Confirm Message Header
 *		Complete Message Type
 *===================================================================*/

CModBusRegInfoArray* COwnModBusDef::GetModBusRegisterArrayByType(
	MODBUS_REG_TYPE_SORT enumRegType, BOOL bCreate)
{
	CModBusRegInfoArray* lpContentArray = NULL;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:	//	Coil : 0
		lpContentArray = m_lparrayCoils;
		if((lpContentArray == NULL) && (bCreate))
		{
			lpContentArray = new CModBusRegInfoArray;
			m_lparrayCoils = lpContentArray;
		}
		break;
	case MODBUS_REG_DISCRET:		//	Discrete State : 1
		lpContentArray = m_lparrayDiscrets;
		if((lpContentArray == NULL) && (bCreate))
		{
			lpContentArray = new CModBusRegInfoArray;
			m_lparrayDiscrets = lpContentArray;
		}
		break;
	case MODBUS_REG_INPUT:	//	Input Register : 2
		lpContentArray = m_lparrayInputs;
		if((lpContentArray == NULL) && (bCreate))
		{
			lpContentArray = new CModBusRegInfoArray;
			m_lparrayInputs = lpContentArray;
		}
		break;
	case MODBUS_REG_HOLD:	//	Hold Reigister : 3
		lpContentArray = m_lparrayHolds;
		if((lpContentArray == NULL) && (bCreate))
		{
			lpContentArray = new CModBusRegInfoArray;
			m_lparrayHolds = lpContentArray;
		}
		break;
	default:
		break;
	}

	return lpContentArray;
}


WORD COwnModBusDef::AppendModBusRegister(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
	MODBUS_MSG_VALUE_TYPE enmuValueType, LPCTSTR lpszName)
{
	WORD nRetVal = 0xFFFF;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType);

	if((lpContentArray != NULL) && (lpContentArray->GetCount() < MODBUS_REGISTER_COUNT))
	{
		
		MODBUS_REGIST_INFO_ST stModBusContent;

		stModBusContent.nAddress = nRegAddr;
		stModBusContent.nMsgType = enmuValueType;
		stModBusContent.strRegName = lpszName;
		stModBusContent.nMsgValue = DWORD(0);

		return (WORD)lpContentArray->Add(stModBusContent);
	}

	return nRetVal;
}

WORD COwnModBusDef::InsertAtModBusRegister(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nInsertPos, WORD nRegAddr, 
	MODBUS_MSG_VALUE_TYPE enmuValueType, LPCTSTR lpszName)
{
	WORD nRetVal = 0xFFFF;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType);

	if((lpContentArray != NULL) && (lpContentArray->GetCount() < MODBUS_REGISTER_COUNT))
	{
		MODBUS_REGIST_INFO_ST stModBusContent;

		stModBusContent.nAddress = nRegAddr;
		stModBusContent.nMsgType = enmuValueType;
		stModBusContent.strRegName = lpszName;
		stModBusContent.nMsgValue = DWORD(0);

		if(nInsertPos < lpContentArray->GetCount())
		{
			lpContentArray->InsertAt(nInsertPos, stModBusContent);
			return nInsertPos;
		}
		else
			return (WORD)lpContentArray->Add(stModBusContent);
	}

	return nRetVal;
}

void COwnModBusDef::RemoveAtModBusRegister(MODBUS_REG_TYPE_SORT enumRegType, WORD nRemovePos)
{
	WORD nRetVal = 0xFFFF;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if((lpContentArray != NULL))
	{
		if(nRemovePos < lpContentArray->GetCount())
		{
			lpContentArray->RemoveAt(nRemovePos);
		}
	}
}

void COwnModBusDef::RemoveAllModbusRegister(MODBUS_REG_TYPE_SORT enumRegType)
{
	WORD nRetVal = 0xFFFF;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if((lpContentArray != NULL))
	{
		lpContentArray->RemoveAll();
	}
}

BOOL COwnModBusDef::ReadRegisterInfoFromFile(LPCTSTR lpszFilePath)
{
	CFile fileConfig;
	BOOL bOpenFlag = fileConfig.Open(lpszFilePath, CFile::modeRead);
	if(bOpenFlag == TRUE)
	{
		fileConfig.Close();
		CString strAppName, strKeyName;

		strAppName = _T("RegInfo");
		int nCoilAmount = ::GetPrivateProfileInt(strAppName, _T("CoilAmount"), 0, lpszFilePath);
		int nDIAmount = ::GetPrivateProfileInt(strAppName, _T("DIAmount"), 0, lpszFilePath);
		int nHoldAmount = ::GetPrivateProfileInt(strAppName, _T("HoldAmount"), 0, lpszFilePath);
		int nInputAmount = ::GetPrivateProfileInt(strAppName, _T("InputAmount"), 0, lpszFilePath);
		
		int nRegAmount;
		MODBUS_REG_TYPE_SORT enumRegType;
		CModBusRegInfoArray** lpRegArrayPtr = NULL;
		for(int nRegTypeId = 0; nRegTypeId < 4; nRegTypeId ++)
		{
			switch(nRegTypeId)
			{
			case 0:
				enumRegType = MODBUS_REG_COIL;
				nRegAmount = nCoilAmount;
				lpRegArrayPtr = &m_lparrayCoils;
				break;
			case 1:
				enumRegType = MODBUS_REG_DISCRET;
				nRegAmount = nDIAmount;
				lpRegArrayPtr = &m_lparrayDiscrets;
				break;
			case 2:
				enumRegType = MODBUS_REG_HOLD;
				nRegAmount = nHoldAmount;
				lpRegArrayPtr = &m_lparrayHolds;
				break;
			default:
				enumRegType = MODBUS_REG_INPUT;
				nRegAmount = nInputAmount;
				lpRegArrayPtr = &m_lparrayInputs;
				break;
			}

			if((*lpRegArrayPtr) != NULL)
			{
				(*lpRegArrayPtr)->RemoveAll();
				delete (*lpRegArrayPtr);
				(*lpRegArrayPtr) = NULL;
			}

			if(nRegAmount > 0)
			{
				(*lpRegArrayPtr) = new CModBusRegInfoArray;
				ReadRegisterInfoFromFileBySort(enumRegType, nRegAmount, lpszFilePath);
			}
		}
	}

	return bOpenFlag;
}


BOOL COwnModBusDef::ReadRegisterInfoFromFileBySort(MODBUS_REG_TYPE_SORT enumRegType, int nRegAmount, LPCTSTR lpszFilePath)
{
	CModBusRegInfoArray* lpRegisterArray = (CModBusRegInfoArray*)
			GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpRegisterArray == NULL)
		return FALSE;

	lpRegisterArray->RemoveAll();

	CString strAppName, strKeyName;
	BOOL bDiscretVal = FALSE;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		strAppName = _T("Coil");
		bDiscretVal = TRUE;
		break;
	case MODBUS_REG_DISCRET:
		strAppName = _T("Discret");
		bDiscretVal = TRUE;
		break;
	case MODBUS_REG_HOLD:
		strAppName = _T("Hold");
		break;
	default:	//	MODBUS_REG_INPUT,
		strAppName = _T("Input");
		break;
	}
	
	MODBUS_REGIST_INFO_ST stRegisterInfo;
	const int nGetProfileLen = 128;
	LPCTSTR lpszDefault = _T("");
	TCHAR lpszGetProfile[nGetProfileLen];

	for(int nRegId = 0; nRegId < nRegAmount; nRegId ++)
	{
		strKeyName.Format(_T("Name%d"), nRegId);
		::GetPrivateProfileString(strAppName, strKeyName, lpszDefault, 
			lpszGetProfile, nGetProfileLen, lpszFilePath);
		stRegisterInfo.strRegName = lpszGetProfile;

		strKeyName.Format(_T("Addr%d"), nRegId);
		stRegisterInfo.nAddress = 
			::GetPrivateProfileInt(strAppName, strKeyName, 0, lpszFilePath);

		if(bDiscretVal == TRUE)
		{
			stRegisterInfo.nMsgType = MODBUS_MSG_BOOL;
		}
		else
		{
			strKeyName.Format(_T("ValType%d"), nRegId);
			stRegisterInfo.nMsgType = (MODBUS_MSG_VALUE_TYPE)
				::GetPrivateProfileInt(strAppName, strKeyName, 0, lpszFilePath);
		}
		stRegisterInfo.nMsgValue = DWORD(0);

		lpRegisterArray->Add(stRegisterInfo);
	}

	return TRUE;
}

BOOL COwnModBusDef::WriteRegisterInfoToFile(LPCTSTR lpszFilePath)
{
	CFile fileConfig;
	BOOL bOpenFlag = fileConfig.Open(lpszFilePath, CFile::modeRead);
	if(bOpenFlag == FALSE)
	{
		bOpenFlag = fileConfig.Open(lpszFilePath, CFile::modeCreate | CFile::modeWrite);
		fileConfig.Close();
	}
	else
		fileConfig.Close();

	if(bOpenFlag == TRUE)
	{
		CString strAppName = _T("RegInfo"), strKeyName, strKeyVal;
		int nCoilAmount = GetModBusRegisterCount(MODBUS_REG_COIL);
		strKeyVal.Format(_T("%d"), nCoilAmount);
		::WritePrivateProfileString(strAppName, _T("CoilAmount"), strKeyVal, lpszFilePath);

		int nDIAmount = GetModBusRegisterCount(MODBUS_REG_DISCRET);
		strKeyVal.Format(_T("%d"), nDIAmount);
		::WritePrivateProfileString(strAppName, _T("DIAmount"), strKeyVal, lpszFilePath);

		int nHoldAmount = GetModBusRegisterCount(MODBUS_REG_HOLD);
		strKeyVal.Format(_T("%d"), nHoldAmount);
		::WritePrivateProfileString(strAppName, _T("HoldAmount"), strKeyVal, lpszFilePath);

		int nInputAmount = GetModBusRegisterCount(MODBUS_REG_INPUT);
		strKeyVal.Format(_T("%d"), nInputAmount);
		::WritePrivateProfileString(strAppName, _T("InputAmount"), strKeyVal, lpszFilePath);

		WriteRegisterInfoToFileBySort(MODBUS_REG_COIL, lpszFilePath);
		WriteRegisterInfoToFileBySort(MODBUS_REG_DISCRET, lpszFilePath);
		WriteRegisterInfoToFileBySort(MODBUS_REG_HOLD, lpszFilePath);
		WriteRegisterInfoToFileBySort(MODBUS_REG_INPUT, lpszFilePath);
	}

	return bOpenFlag;
}

BOOL COwnModBusDef::WriteRegisterInfoToFileBySort(MODBUS_REG_TYPE_SORT enumRegType, LPCTSTR lpszFilePath)
{
	CModBusRegInfoArray* lpRegisterArray = (CModBusRegInfoArray*)
			GetModBusRegisterArrayByType(enumRegType, FALSE);

	if((lpRegisterArray == NULL) || (lpRegisterArray->GetCount() == 0))
		return TRUE;

	CString strAppName, strKeyName, strKeyVal;
	BOOL bDiscretVal = FALSE;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		strAppName = _T("Coil");
		bDiscretVal = TRUE;
		break;
	case MODBUS_REG_DISCRET:
		strAppName = _T("Discret");
		bDiscretVal = TRUE;
		break;
	case MODBUS_REG_HOLD:
		strAppName = _T("Hold");
		break;
	default:	//	MODBUS_REG_INPUT,
		strAppName = _T("Input");
		break;
	}

	int nCoilAmount = (int)lpRegisterArray->GetCount();
	for(int nRegId = 0; nRegId < nCoilAmount; nRegId ++)
	{
		MODBUS_REGIST_INFO_ST& stRegistInfo = lpRegisterArray->ElementAt(nRegId);

		strKeyName.Format(_T("Name%d"), nRegId);
		::WritePrivateProfileString(strAppName, strKeyName, 
			stRegistInfo.strRegName, lpszFilePath);

		strKeyName.Format(_T("Addr%d"), nRegId);
		strKeyVal.Format(_T("%d"), stRegistInfo.nAddress);
		::WritePrivateProfileString(strAppName, strKeyName, strKeyVal, lpszFilePath);

		if(bDiscretVal == FALSE)
		{
			strKeyName.Format(_T("ValType%d"), nRegId);
			strKeyVal.Format(_T("%d"), stRegistInfo.nMsgType);
			::WritePrivateProfileString(strAppName, strKeyName, strKeyVal, lpszFilePath);
		}
	}
	return TRUE;
}

/*====================================================*
 *
 *
 *====================================================*/
BOOL COwnModBusDef::ParseRecvMessageCommonHeader(void)
{
	BOOL bRetVal = TRUE;
	if(m_boolEthernetType == FALSE)
	{
		if(m_stRxMsgInfo.nRemainLen >= 1)
		{
			if(m_byteSlaveNum == (BYTE)*m_stRxMsgInfo.bufRxMsg)
			{
				m_stRxMsgInfo.nCheckedLen = 1;
				m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_COMMAND;
			}
			else
				bRetVal = FALSE;
		}
	}
	else
	{
		if(m_stRxMsgInfo.nRemainLen >= MODBUS_TCP_MBAP_LEN)
		{
			char *lpMsgBuf = m_stRxMsgInfo.bufRxMsg;
			m_stRxMsgInfo.nTransactionId = *((WORD*)lpMsgBuf);
			lpMsgBuf += 2;

			if((*(WORD*)lpMsgBuf) == 0x0000)
			{
				lpMsgBuf += 4;

				if(*(BYTE*)lpMsgBuf == m_byteSlaveNum)
				{
					m_stRxMsgInfo.nCheckedLen = MODBUS_TCP_MBAP_LEN;
					m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_COMMAND;
				}
				else
					bRetVal = FALSE;
			}
			else
				bRetVal = FALSE;
		}
	}

	return bRetVal;
}

WORD COwnModBusDef::ConstructTransMessageCommonHeader(void)
{
	char *lpMsgBody = m_stTxMsgInfo.bufTxMsg;
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;

	if(m_boolEthernetType == TRUE)
	{
		*((unsigned long*)lpMsgBody) = 0x00000000;
		lpMsgBody += 4;
		*((unsigned short*)lpMsgBody) = 0x0000;
		lpMsgBody += 2;
		nMsgLen += 6;
	}

	*((BYTE*)lpMsgBody) = m_byteSlaveNum;

	nMsgLen ++;

	return nMsgLen;
}

WORD COwnModBusDef::ConstructTransMessageComplete(void)
{
	char *lpMsgBody = m_stTxMsgInfo.bufTxMsg;
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen; 
	if(m_boolEthernetType == TRUE)
	{
		lpMsgBody += 4;
		WORD nBodyLen = nMsgLen - 6;
		MODBUS_WORD_TO_MSG(lpMsgBody, nBodyLen);
	}
	else
	{
		WORD nCRCVal = GetModBusCRCSumValue(lpMsgBody, nMsgLen);
		lpMsgBody += nMsgLen;
		*((WORD*)lpMsgBody) = nCRCVal;

		nMsgLen += 2;
	}

	return nMsgLen;
}

WORD COwnModBusDef::GetModBusRegisterCount(MODBUS_REG_TYPE_SORT enumRegType)
{
	WORD nRetVal = 0;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		nRetVal = (WORD)lpContentArray->GetCount();
	}
	return nRetVal;
}

BOOL COwnModBusDef::GetModBusRegisterProperty(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegId, 
	WORD& nAddr, WORD& nValueType, CString& strName)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegId)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegId);
			nAddr = stRegisterInfo.nAddress;
			nValueType = stRegisterInfo.nMsgType;
			strName = stRegisterInfo.strRegName;

			bRetVal = TRUE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::GetModBusRegisterProperty(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegId, 
	MODBUS_REGIST_INFO_ST& stRegisterInfo)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegId)
		{
			stRegisterInfo = lpContentArray->ElementAt(nRegId);
			bRetVal = TRUE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::GetModBusRegisterValueByAddr(MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, LPVOID lpGetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		for(WORD nRegId = 0; nRegId < nRegCount; nRegId ++)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegId);
			if(nRegAddr == stRegisterInfo.nAddress)
			{
				ConvertDataFromRegisterByValType(stRegisterInfo.nMsgType, 
					stRegisterInfo.nMsgValue, lpGetData);

				bRetVal = TRUE;
				break;
			}
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::GetModBusRegisterValueByIndex(MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, LPVOID lpGetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegIndex)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegIndex);
			ConvertDataFromRegisterByValType(stRegisterInfo.nMsgType, 
				stRegisterInfo.nMsgValue, lpGetData);

			bRetVal = TRUE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::GetModBusRegisterValueByIndexEx(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, 
	MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpGetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegIndex)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegIndex);

			if(stRegisterInfo.nMsgType == enumValType)
			{
				ConvertDataFromRegisterByValType(
					stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
					lpGetData);
			}
			else
			{
				ConvertDataFromRegisterByValTypeEx(
					stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
					enumValType, lpGetData);
			}
			bRetVal = TRUE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::GetModBusRegisterValueByAddrEx(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
	MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpGetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		for(WORD nRegId = 0; nRegId < nRegCount; nRegId ++)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegId);
			if(nRegAddr == stRegisterInfo.nAddress)
			{
				if(stRegisterInfo.nMsgType == enumValType)
				{
					ConvertDataToRegisterByValType(
						stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
						lpGetData);
				}
				else
				{
					ConvertDataToRegisterByValTypeEx(
						stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
						enumValType, lpGetData);
				}
				bRetVal = TRUE;
				break;
			}
		}
	}
	return bRetVal;
}

void COwnModBusDef::GetModBusRegisterDataTextFormat(CString& strValueText, 
		LPVOID lpData, MODBUS_MSG_VALUE_TYPE enumValType, int nBoolType)
{
		switch(enumValType)
		{
		case MODBUS_MSG_BOOL:
			{
				BOOL bRegVal = *(BOOL*)(lpData);
				if(((nBoolType == 1) || (nBoolType == 2)) && 
					((bRegVal == TRUE) || (bRegVal == FALSE)))
				{
					if(nBoolType == 1)
					{
						if(bRegVal == TRUE)
							strValueText = _T("TRUE");
						else
							strValueText = _T("FALSE");
					}
					else
					{
						if(bRegVal == TRUE)
							strValueText = _T("ON");
						else
							strValueText = _T("OFF");
					}
				}
				else
					strValueText.Format(_T("%d"), bRegVal);
			}
			break;
		case MODBUS_MSG_INT:
			strValueText.Format(_T("%d"), *(short*)(lpData));
			break;
		case MODBUS_MSG_UINT:
			strValueText.Format(_T("%u"), *(WORD*)(lpData));
			break;
		case MODBUS_MSG_REAL:
			{
				float flRegVal = *(float*)(lpData);
				float flConvValue = (flRegVal < 0) ? -flRegVal : flRegVal;
				if(flConvValue < 1000000.0f)
				{
					CString strFormat;
					int nFractLen = 0;
					if(flConvValue < 10.0f)
						nFractLen = 6;
					else if(flConvValue < 100.0f)
						nFractLen = 5;
					else if(flConvValue < 1000.0f)
						nFractLen = 4;
					else if(flConvValue < 10000.0f)
						nFractLen = 3;
					else if(flConvValue < 100000.0f)
						nFractLen = 2;
					else
						nFractLen = 1;

					strFormat.Format(_T("%%.%df"), nFractLen);
					strValueText.Format(strFormat, flRegVal);
					int nZeroCheckLen = nFractLen;

					while(nZeroCheckLen > 0)
					{
						strFormat = strValueText.Right(nZeroCheckLen);
						if(wcstol(strFormat, NULL, 10) == 0)
							break;
						nZeroCheckLen --;
					}

					if(nZeroCheckLen > 0)
					{
						if(nZeroCheckLen == nFractLen)
							nZeroCheckLen ++;

						strFormat = strValueText.Left(strValueText.GetLength() - nZeroCheckLen);
						strValueText = strFormat;
					}
				}
				else
				{
					strValueText.Format(_T("%E"), flRegVal);
				}
			}
			break;
		case MODBUS_MSG_LONG:
			strValueText.Format(_T("%d"), *(long*)(lpData));
			break;
		case MODBUS_MSG_ULONG:
			strValueText.Format(_T("%u"), *((DWORD*)lpData));
			break;
		default:	//	case MODBUS_MSG_STRING
			strValueText.Empty();
			break;
		}
}

LPCTSTR COwnModBusDef::GetModBusRegisterValueStringByAddr(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, int nBoolType)
{
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray == NULL)
		return NULL;

	LPCTSTR lpszRetVal = NULL;
	WORD nRegCount = (WORD)lpContentArray->GetCount();
	for(WORD nRegId = 0; nRegId < nRegCount; nRegId ++)
	{
		MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegId);
		if(nRegAddr == stRegisterInfo.nAddress)
		{
			GetModBusRegisterDataTextFormat(m_stringTempTextStore, 
				&(stRegisterInfo.nMsgValue), stRegisterInfo.nMsgType, nBoolType);
			lpszRetVal = (LPCTSTR)m_stringTempTextStore;
			break;
		}
	}
	return lpszRetVal;
}

LPCTSTR COwnModBusDef::GetModBusRegisterValueStringByIndex(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, int nBoolType)
{
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	LPCTSTR lpszRetVal = NULL;
	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegIndex)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegIndex);
			GetModBusRegisterDataTextFormat(m_stringTempTextStore, 
				&(stRegisterInfo.nMsgValue), stRegisterInfo.nMsgType, nBoolType);
			lpszRetVal = (LPCTSTR)m_stringTempTextStore;
		}
	}
	return lpszRetVal;
}

BOOL COwnModBusDef::SetModBusRegisterValueByIndex(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, LPVOID lpSetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegIndex)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegIndex);
			ConvertDataToRegisterByValType(stRegisterInfo.nMsgType, 
				stRegisterInfo.nMsgValue, lpSetData);

			bRetVal = TRUE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::SetModBusRegisterValueByIndexEx(
		MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, 
		MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpSetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		if(nRegCount > nRegIndex)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegIndex);
			if(stRegisterInfo.nMsgType == enumValType)
			{
				ConvertDataToRegisterByValType(
					stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
					lpSetData);
			}
			else
			{
				ConvertDataToRegisterByValTypeEx(
					stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
					enumValType, lpSetData);
			}

			bRetVal = TRUE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::SetModBusRegisterValueByAddr(
	MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, LPVOID lpSetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		for(WORD nRegId = 0; nRegId < nRegCount; nRegId ++)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegId);
			if(nRegAddr == stRegisterInfo.nAddress)
			{
				ConvertDataToRegisterByValType(stRegisterInfo.nMsgType, 
					stRegisterInfo.nMsgValue, lpSetData);

				bRetVal = TRUE;
				break;
			}
		}
	}
	return bRetVal;
}

BOOL COwnModBusDef::SetModBusRegisterValueByAddrEx(
		MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
		MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpSetData)
{
	BOOL bRetVal = FALSE;
	CModBusRegInfoArray* lpContentArray = (CModBusRegInfoArray*)
		GetModBusRegisterArrayByType(enumRegType, FALSE);

	if(lpContentArray)
	{
		WORD nRegCount = (WORD)lpContentArray->GetCount();
		for(WORD nRegId = 0; nRegId < nRegCount; nRegId ++)
		{
			MODBUS_REGIST_INFO_ST& stRegisterInfo = lpContentArray->ElementAt(nRegId);

			if(nRegAddr == stRegisterInfo.nAddress)
			{
				if(stRegisterInfo.nMsgType == enumValType)
				{
					ConvertDataToRegisterByValType(
						stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
						lpSetData);
				}
				else
				{
					ConvertDataToRegisterByValTypeEx(
						stRegisterInfo.nMsgType, stRegisterInfo.nMsgValue, 
						enumValType, lpSetData);
				}
				bRetVal = TRUE;
				break;
			}
		}
	}
	return bRetVal;
}

void COwnModBusDef::ConvertDataFromRegisterByValType(MODBUS_MSG_VALUE_TYPE enumMsgType, DWORD nRegValue, LPVOID lpGetData)
{
	switch(enumMsgType)
	{
	case MODBUS_MSG_BOOL:
	case MODBUS_MSG_INT:
	case MODBUS_MSG_UINT:
		*(WORD*)lpGetData = ((WORD)nRegValue);
		break;
	case MODBUS_MSG_REAL:
	case MODBUS_MSG_LONG:
	case MODBUS_MSG_ULONG:
		*(DWORD*)lpGetData = nRegValue;
		break;
	default:	//	case MODBUS_MSG_STRING
		break;
	}
}

void COwnModBusDef::ConvertDataFromRegisterByValTypeEx(
	MODBUS_MSG_VALUE_TYPE enumMsgType, DWORD nRegValue, 
	MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpGetData)
{
	switch(enumValType)
	{
	case MODBUS_MSG_BOOL:
	case MODBUS_MSG_INT:
		switch(enumMsgType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			*(INT*)lpGetData = nRegValue;
			break;
		case MODBUS_MSG_UINT:
			*(INT*)lpGetData = (BOOL)nRegValue;
			break;
		case MODBUS_MSG_REAL:
			*(INT*)lpGetData = (BOOL)(*((FLOAT*)&nRegValue));
			break;
		case MODBUS_MSG_LONG:
			*(INT*)lpGetData = (BOOL)(*((LONG*)&nRegValue));
			break;
		case MODBUS_MSG_ULONG:
			*(INT*)lpGetData = (BOOL)(*((ULONG*)&nRegValue));
			break;
		}
		break;
	case MODBUS_MSG_UINT:
		switch(enumMsgType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			*(UINT*)lpGetData = (UINT)nRegValue;
			break;
		case MODBUS_MSG_UINT:
			*(UINT*)lpGetData = (UINT)(*((UINT*)&nRegValue));
			break;
		case MODBUS_MSG_REAL:
			*(UINT*)lpGetData = (UINT)(*((FLOAT*)&nRegValue));
			break;
		case MODBUS_MSG_LONG:
			*(UINT*)lpGetData = (UINT)(*((LONG*)&nRegValue));
			break;
		case MODBUS_MSG_ULONG:
			*(UINT*)lpGetData = (UINT)(*((ULONG*)&nRegValue));
			break;
		}
		break;
	case MODBUS_MSG_REAL:
		switch(enumMsgType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			*(FLOAT*)lpGetData = (FLOAT)(*((INT*)&nRegValue));
			break;
		case MODBUS_MSG_UINT:
			*(FLOAT*)lpGetData = (FLOAT)(*((UINT*)&nRegValue));
			break;
		case MODBUS_MSG_REAL:
			*(FLOAT*)lpGetData = (FLOAT)(*((FLOAT*)&nRegValue));
			break;
		case MODBUS_MSG_LONG:
			*(FLOAT*)lpGetData = (FLOAT)(*((LONG*)&nRegValue));
			break;
		case MODBUS_MSG_ULONG:
			*(FLOAT*)lpGetData = (FLOAT)(*((ULONG*)&nRegValue));
			break;
		}
		break;
	case MODBUS_MSG_LONG:
		switch(enumMsgType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			*(LONG*)lpGetData = (LONG)(*((INT*)&nRegValue));
			break;
		case MODBUS_MSG_UINT:
			*(LONG*)lpGetData = (LONG)(*((UINT*)&nRegValue));
			break;
		case MODBUS_MSG_REAL:
			*(LONG*)lpGetData = (LONG)(*((FLOAT*)&nRegValue));
			break;
		case MODBUS_MSG_LONG:
			*(LONG*)lpGetData = (LONG)(*((LONG*)&nRegValue));
			break;
		case MODBUS_MSG_ULONG:
			*(LONG*)lpGetData = (LONG)(*((ULONG*)&nRegValue));
			break;
		}
		break;
	case MODBUS_MSG_ULONG:
		switch(enumMsgType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			*(ULONG*)lpGetData = (ULONG)(*((INT*)&nRegValue));
			break;
		case MODBUS_MSG_UINT:
			*(ULONG*)lpGetData = (ULONG)(*((UINT*)&nRegValue));
			break;
		case MODBUS_MSG_REAL:
			*(ULONG*)lpGetData = (ULONG)(*((FLOAT*)&nRegValue));
			break;
		case MODBUS_MSG_LONG:
			*(ULONG*)lpGetData = (ULONG)(*((LONG*)&nRegValue));
			break;
		case MODBUS_MSG_ULONG:
			*(ULONG*)lpGetData = (ULONG)(*((ULONG*)&nRegValue));
			break;
		}
		break;
	default:
		break;
	}
}

void COwnModBusDef::ConvertDataToRegisterByValType(
	MODBUS_MSG_VALUE_TYPE enumMsgType, DWORD& nRegValue, LPVOID lpSetData)
{
	switch(enumMsgType)
	{
	case MODBUS_MSG_BOOL:
	case MODBUS_MSG_INT:
	case MODBUS_MSG_UINT:
		nRegValue = (DWORD)(*(WORD*)lpSetData);
		break;
	case MODBUS_MSG_REAL:
	case MODBUS_MSG_LONG:
	case MODBUS_MSG_ULONG:
		nRegValue = *(DWORD*)lpSetData;
		break;
	default:	//	case MODBUS_MSG_STRING
		break;
	}
}

void COwnModBusDef::ConvertDataToRegisterByValTypeEx(
	MODBUS_MSG_VALUE_TYPE enumMsgType, DWORD& nRegValue, 
	MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpSetData)
{
	switch(enumMsgType)
	{
	case MODBUS_MSG_BOOL:
	case MODBUS_MSG_INT:
		switch(enumValType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			nRegValue = (DWORD)((INT)(*(INT*)lpSetData));
			break;
		case MODBUS_MSG_UINT:
			nRegValue = (DWORD)((INT)(*(UINT*)lpSetData));
			break;
		case MODBUS_MSG_REAL:
			nRegValue = (DWORD)((INT)(*(FLOAT*)lpSetData));
			break;
		case MODBUS_MSG_LONG:
			nRegValue = (DWORD)((INT)(*(LONG*)lpSetData));
			break;
		case MODBUS_MSG_ULONG:
			nRegValue = (DWORD)((INT)(*(ULONG*)lpSetData));
			break;
		}
		break;
	case MODBUS_MSG_UINT:
		switch(enumValType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			nRegValue = (DWORD)((UINT)(*(INT*)lpSetData));
			break;
		case MODBUS_MSG_UINT:
			nRegValue = (DWORD)((UINT)(*(UINT*)lpSetData));
			break;
		case MODBUS_MSG_REAL:
			nRegValue = (DWORD)((UINT)(*(FLOAT*)lpSetData));
			break;
		case MODBUS_MSG_LONG:
			nRegValue = (DWORD)((UINT)(*(LONG*)lpSetData));
			break;
		case MODBUS_MSG_ULONG:
			nRegValue = (DWORD)((UINT)(*(ULONG*)lpSetData));
			break;
		}
		break;
	case MODBUS_MSG_REAL:
		switch(enumValType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			nRegValue = (DWORD)((FLOAT)(*(INT*)lpSetData));
			break;
		case MODBUS_MSG_UINT:
			nRegValue = (DWORD)((FLOAT)(*(UINT*)lpSetData));
			break;
		case MODBUS_MSG_REAL:
			nRegValue = (DWORD)((FLOAT)(*(FLOAT*)lpSetData));
			break;
		case MODBUS_MSG_LONG:
			nRegValue = (DWORD)((FLOAT)(*(LONG*)lpSetData));
			break;
		case MODBUS_MSG_ULONG:
			nRegValue = (DWORD)((FLOAT)(*(ULONG*)lpSetData));
			break;
		}
		break;
	case MODBUS_MSG_LONG:
		switch(enumValType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			nRegValue = (DWORD)((LONG)(*(INT*)lpSetData));
			break;
		case MODBUS_MSG_UINT:
			nRegValue = (DWORD)((LONG)(*(UINT*)lpSetData));
			break;
		case MODBUS_MSG_REAL:
			nRegValue = (DWORD)((LONG)(*(FLOAT*)lpSetData));
			break;
		case MODBUS_MSG_LONG:
			nRegValue = (DWORD)((LONG)(*(LONG*)lpSetData));
			break;
		case MODBUS_MSG_ULONG:
			nRegValue = (DWORD)((LONG)(*(ULONG*)lpSetData));
			break;
		}
		break;
	case MODBUS_MSG_ULONG:
		switch(enumValType)
		{
		case MODBUS_MSG_BOOL:
		case MODBUS_MSG_INT:
			nRegValue = (DWORD)((ULONG)(*(INT*)lpSetData));
			break;
		case MODBUS_MSG_UINT:
			nRegValue = (DWORD)((ULONG)(*(UINT*)lpSetData));
			break;
		case MODBUS_MSG_REAL:
			nRegValue = (DWORD)((ULONG)(*(FLOAT*)lpSetData));
			break;
		case MODBUS_MSG_LONG:
			nRegValue = (DWORD)((ULONG)(*(LONG*)lpSetData));
			break;
		case MODBUS_MSG_ULONG:
			nRegValue = (DWORD)((ULONG)(*(ULONG*)lpSetData));
			break;
		}
		break;
	default:	//	case MODBUS_MSG_STRING
		break;
	}
}

COwnModBusDef& COwnModBusDef::operator=(COwnModBusDef& clsSrcDef)
{
	//TODO: insert return statement here

	CopyRegisterInfoArray(MODBUS_REG_COIL,	clsSrcDef.m_lparrayCoils);
	CopyRegisterInfoArray(MODBUS_REG_DISCRET,	clsSrcDef.m_lparrayDiscrets);
	CopyRegisterInfoArray(MODBUS_REG_HOLD,	clsSrcDef.m_lparrayHolds);
	CopyRegisterInfoArray(MODBUS_REG_INPUT, clsSrcDef.m_lparrayInputs);

	m_byteSlaveNum		= clsSrcDef.m_byteSlaveNum;
	m_boolMaster		= clsSrcDef.m_boolMaster;
	m_boolEthernetType	= clsSrcDef.m_boolEthernetType;
	m_boolASCMode		= clsSrcDef.m_boolASCMode;

	m_stRequestInfo = clsSrcDef.m_stRequestInfo;
	m_stRxMsgInfo	= clsSrcDef.m_stRxMsgInfo;

	m_arrayForceErrAddr.RemoveAll();
	m_arrayForceErrAddr.Copy(clsSrcDef.m_arrayForceErrAddr);

	m_arrayReadErrAddr.RemoveAll();
	m_arrayReadErrAddr.Copy(clsSrcDef.m_arrayReadErrAddr);

	m_stringDevSeriesName = clsSrcDef.m_stringDevSeriesName;

	return *this;
}

void COwnModBusDef::CopyRegisterInfoArray(MODBUS_REG_TYPE_SORT enumRegType, CModBusRegInfoArray* lparrayRegInfo)
{
	CModBusRegInfoArray** lpptrDstArray = NULL;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		lpptrDstArray = &m_lparrayCoils;
		break;
	case MODBUS_REG_DISCRET:
		lpptrDstArray = &m_lparrayDiscrets;
		break;
	case MODBUS_REG_HOLD:
		lpptrDstArray = &m_lparrayHolds;
		break;
	case MODBUS_REG_INPUT:
		lpptrDstArray = &m_lparrayInputs;
		break;
	}

	if(lparrayRegInfo == NULL)
	{
		if(*lpptrDstArray != NULL)
		{
			(*lpptrDstArray)->RemoveAll();
			delete (*lpptrDstArray);
			(*lpptrDstArray) = NULL;
		}
	}
	else
	{
		if(*lpptrDstArray == NULL)
			(*lpptrDstArray) = new CModBusRegInfoArray;
		else
			(*lpptrDstArray)->RemoveAll();

		(*lpptrDstArray)->Copy(*lparrayRegInfo);
	}
}

BOOL COwnModBusDef::GetRecvMessageIsBusy(void)
{
	return m_stRxMsgInfo.bBusyFlag;
}

void COwnModBusDef::ResetRecvErrorState(void)
{
	m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_NONE;
	m_arrayForceErrAddr.RemoveAll();
	m_arrayReadErrAddr.RemoveAll();
}

void COwnModBusDef::SetModBusDevSeriesName(LPCTSTR lpszSeriesName)
{
	m_stringDevSeriesName = lpszSeriesName;
}

LPCTSTR COwnModBusDef::GetModBusDevSeriesName(void)
{
	return (LPCTSTR)m_stringDevSeriesName;
}

long COwnModBusDef::CheckModBusRegisterOverLayAddress(
	MODBUS_REG_TYPE_SORT enumRegType, long* lpOverLayId2nd)
{
	return CheckModBusRegOverLayAddressInInfoArray(
		(CModBusRegInfoArray*)GetModBusRegisterArrayByType(enumRegType, FALSE), 
		lpOverLayId2nd);
}

long COwnModBusDef::CheckModBusRegisterOverLayName(
	MODBUS_REG_TYPE_SORT enumRegType, long* lpOverLayId2nd)
{
	return CheckModBusRegOverLayAddressInInfoArray(
		(CModBusRegInfoArray*)GetModBusRegisterArrayByType(enumRegType, FALSE), 
		lpOverLayId2nd);
}

long COwnModBusDef::CheckModBusRegOverLayAddressInInfoArray(CModBusRegInfoArray* lpRegInfo, long* lpOverLayId2nd)
{
	long nOverLay1st = -1, nOverLay2nd = -1;
	if((lpRegInfo != NULL) || (lpRegInfo->GetCount() > 0))
	{
		long nRegCount = (long)lpRegInfo->GetCount();
		BOOL bRegNameOverLay = FALSE;
		nRegCount --;

		for(int nCheckId = 0; nCheckId < nRegCount; nCheckId ++)
		{
			MODBUS_REGIST_INFO_ST& stCheckRegister = lpRegInfo->ElementAt(nCheckId);

			nOverLay2nd = CheckModBusRegOverLayAddrFromInfoArray(
				lpRegInfo,
				stCheckRegister.nAddress, 
				stCheckRegister.nMsgType, 
				nCheckId, nCheckId + 1);

			if(nOverLay2nd >= 0)
			{
				nOverLay1st = nCheckId;
				break;
			}
		}
	}

	if(lpOverLayId2nd)
		*lpOverLayId2nd = nOverLay2nd;

	return nOverLay1st;
}

long COwnModBusDef::CheckModBusRegOverLayNameInInfoArray(CModBusRegInfoArray* lpRegInfo, long* lpOverLayId2nd)
{
	long nOverLay1st = -1, nOverLay2nd = -1;
	if((lpRegInfo != NULL) && (lpRegInfo->GetCount() > 0))
	{
		long nRegCount = (long)lpRegInfo->GetCount();
		nRegCount --;

		for(int nCheckId = 0; nCheckId < nRegCount; nCheckId ++)
		{
			MODBUS_REGIST_INFO_ST& stCheckRegister = lpRegInfo->ElementAt(nCheckId);

				nOverLay2nd = CheckModBusRegOverLayNameFromInfoArray(
					lpRegInfo,
					stCheckRegister.strRegName, 
					nCheckId, nCheckId + 1);

				if(nOverLay2nd >= 0)
				{
					nOverLay1st = nCheckId;
					break;
				}
		}
	}

	if(lpOverLayId2nd)
		*lpOverLayId2nd = nOverLay2nd;
	return nOverLay1st;
}

long COwnModBusDef::CheckModBusRegOverLayAddrFromInfoArray(CModBusRegInfoArray* lpRegInfo, 
		WORD nChkAddr, WORD nChkType, long nExceptId, long nStartId)
{
	long nRetOverLayId = -1;
	if((lpRegInfo == NULL) || (lpRegInfo->GetCount() == 0))
		return nRetOverLayId;

	WORD nRegEnd, nRegAddr;
	WORD nChkEnd = (nChkType < 3) ? 1 : 2;
	nChkEnd += nChkAddr;

	long nRegAmount = (long)lpRegInfo->GetCount();

	for(long nRegId = nStartId; nRegId < nRegAmount; nRegId ++)
	{
		if(nExceptId == nRegId)
			continue;

		MODBUS_REGIST_INFO_ST& stCheckRegister = 
			lpRegInfo->ElementAt(nRegId);

		nRegAddr = stCheckRegister.nAddress;
		nRegEnd = (stCheckRegister.nMsgType < 3) ? 1 : 2;
		nRegEnd += nRegAddr;

		if(((nRegAddr >= nChkAddr) && (nRegAddr < nChkEnd)) ||
			((nRegAddr < nChkAddr) && (nRegEnd > nChkAddr)))
		{
			nRetOverLayId = nRegId;
			break;
		}
	}

	return nRetOverLayId;
}

long COwnModBusDef::CheckModBusRegOverLayNameFromInfoArray(CModBusRegInfoArray* lpRegInfo, 
		LPCTSTR lpszChkName, long nExceptId, long nStartId)
{
	long nRetOverLayId = -1;
	if((lpRegInfo == NULL) || (lpRegInfo->GetCount() == 0))
		return nRetOverLayId;

	long nRegAmount = (long)lpRegInfo->GetCount();

	for(long nRegId = nStartId; nRegId < nRegAmount; nRegId ++)
	{
		if(nExceptId == nRegId)
			continue;

		MODBUS_REGIST_INFO_ST& stCheckRegister = 
			lpRegInfo->ElementAt(nRegId);

		if(stCheckRegister.strRegName.Compare(lpszChkName) == 0)
		{
			nRetOverLayId = nRegId;
			break;
		}
	}

	return nRetOverLayId;
}

BOOL COwnModBusDef::GetModbusPHYLinkTypeEthernet(void)
{
	return m_boolEthernetType;
}

LPCTSTR COwnModBusDef::GetModBusRegisterDataTypeString(MODBUS_MSG_VALUE_TYPE enumDataType, CString& strTypeDef)
{
	switch(enumDataType)
	{
	case MODBUS_MSG_BOOL:
		strTypeDef = _T("BOOL");
		break;
	case MODBUS_MSG_INT:
		strTypeDef = _T("INT");
		break;
	case MODBUS_MSG_UINT:
		strTypeDef = _T("UINT");
		break;
	case MODBUS_MSG_REAL:
		strTypeDef = _T("REAL");
		break;
	case MODBUS_MSG_LONG:
		strTypeDef = _T("LONG");
		break;
	case MODBUS_MSG_ULONG:
		strTypeDef = _T("ULONG");
		break;
	default:
		strTypeDef = _T("(Unknown)");
		break;
	}

	return (LPCTSTR)strTypeDef;
}

LPCTSTR COwnModBusDef::GetModBusRegisterDataTypeString(MODBUS_MSG_VALUE_TYPE enumDataType)
{
	switch(enumDataType)
	{
	case MODBUS_MSG_BOOL:
		m_stringTempTextStore = _T("BOOL");
		break;
	case MODBUS_MSG_INT:
		m_stringTempTextStore = _T("INT");
		break;
	case MODBUS_MSG_UINT:
		m_stringTempTextStore = _T("UINT");
		break;
	case MODBUS_MSG_REAL:
		m_stringTempTextStore = _T("REAL");
		break;
	case MODBUS_MSG_LONG:
		m_stringTempTextStore = _T("LONG");
		break;
	case MODBUS_MSG_ULONG:
		m_stringTempTextStore = _T("ULONG");
		break;
	default:
		m_stringTempTextStore = _T("(Unknown)");
		break;
	}

	return (LPCTSTR)m_stringTempTextStore;
}

LPCTSTR COwnModBusDef::GetModBusRegisterName(MODBUS_REG_TYPE_SORT enumRegSortType, WORD nRegId)
{
	LPCTSTR lpszRetName = NULL;
	CModBusRegInfoArray* lparrayRegInfo = 
		GetModBusRegisterArrayByType(enumRegSortType, FALSE);

	if((lparrayRegInfo) && (nRegId < (WORD)lparrayRegInfo->GetCount()))
	{
		lpszRetName = (LPCTSTR)(lparrayRegInfo->ElementAt(nRegId).strRegName);
	}
	return lpszRetName;
}

WORD COwnModBusDef::GetModBusRegisterDataType(MODBUS_REG_TYPE_SORT enumRegSortType, WORD nRegId)
{
	WORD nRetType = 0xFFFF;

	CModBusRegInfoArray* lparrayRegInfo = 
		GetModBusRegisterArrayByType(enumRegSortType, FALSE);

	if((lparrayRegInfo) && (nRegId < (WORD)lparrayRegInfo->GetCount()))
		nRetType = (WORD)(lparrayRegInfo->ElementAt(nRegId).nMsgType);

	return nRetType;
}

WORD COwnModBusDef::GetModBusRegisterAddress(MODBUS_REG_TYPE_SORT enumRegSortType, WORD nRegId)
{
	WORD nRetAddress = 0xFFFF;

	CModBusRegInfoArray* lparrayRegInfo = 
		GetModBusRegisterArrayByType(enumRegSortType, FALSE);

	if((lparrayRegInfo) && (nRegId < (WORD)lparrayRegInfo->GetCount()))
		nRetAddress = lparrayRegInfo->ElementAt(nRegId).nAddress;

	return nRetAddress;
}

int COwnModBusDef::CheckModBusMessageCorrect(void)
{
	return (int)m_stRequestInfo.enumErrState;
}

int COwnModBusDef::CheckModBusClassMasterType(void)
{
	return m_intModBusMasterType;
}
