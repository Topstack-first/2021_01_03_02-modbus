#pragma once
#include "afxcoll.h"

enum MODBUS_REG_TYPE_SORT{
	MODBUS_REG_COIL = 0x00,
	MODBUS_REG_DISCRET,
	MODBUS_REG_HOLD,
	MODBUS_REG_INPUT,
};

enum MODBUS_MSG_VALUE_TYPE{
	MODBUS_MSG_BOOL = 0,
	MODBUS_MSG_INT,
	MODBUS_MSG_UINT,
	MODBUS_MSG_REAL,
	MODBUS_MSG_LONG,
	MODBUS_MSG_ULONG,
	MODBUS_MSG_STRING
};

//	ModBus Register Type
typedef struct tagMODBUS_REGIST_INFO_ST
{
	CString strRegName;
	WORD nAddress;
	DWORD nMsgValue;
	MODBUS_MSG_VALUE_TYPE nMsgType;
//	MODBUS_LINK_VALUE_TYPE nDataType;
}MODBUS_REGIST_INFO_ST, *LPMODBUS_REGIST_INFO_ST;

typedef CArray<MODBUS_REGIST_INFO_ST, MODBUS_REGIST_INFO_ST> CModBusRegInfoArray;

enum MODBUS_MSG_ILLEGAL_TYPE
{
	MODBUS_ILLEGAL_NONE = 0,
	MODBUS_ILLEGAL_FUNC,
	MODBUS_ILLEGAL_ADDR,
	MODBUS_ILLEGAL_VALUE,
	MODBUS_ILLEGAL_CHECK
};

enum MODBUS_DEVICE_SORT_TYPE
{
	MODBUS_CLASS_TYPE_SLAVE = 0,
	MODBUS_CLASS_TYPE_MASTER
};

class COwnModBusDef
{
public:
	COwnModBusDef(void);
	~COwnModBusDef(void);

protected:
/*=============================================
 *	Convert Macro for Data Message
 *=============================================*/
#define MODBUS_WORD_TO_MSG(pMsg, nWord)	{		\
	*pMsg ++ = (BYTE)((nWord >> 8) & 0xFF);		\
	*pMsg ++ = (BYTE)(nWord & 0xFF);			\
}

#define MODBUS_DWORD_TO_MSG(pMsg, nDWord)	{	\
	*pMsg ++ = (BYTE)((nDWord >> 8) & 0xFF);	\
	*pMsg ++ = (BYTE)(nDWord & 0xFF);			\
	*pMsg ++ = (BYTE)((nDWord >> 24) & 0xFF);	\
	*pMsg ++ = (BYTE)((nDWord >> 16) & 0xFF);	\
}
/*
#define MODBUS_DWORD_TO_MSG(pMsg, nDWord)	{	\
	*pMsg ++ = (BYTE)((nDWord >> 24) & 0xFF);	\
	*pMsg ++ = (BYTE)((nDWord >> 16) & 0xFF);	\
	*pMsg ++ = (BYTE)((nDWord >> 8) & 0xFF);	\
	*pMsg ++ = (BYTE)(nDWord & 0xFF);			\
}*/

#define MODBUS_WORD_FROM_MSG(pMsg, nWord) {		\
	nWord = (WORD)((*pMsg ++) << 8) & 0xFF00;	\
	nWord |= (WORD)((*pMsg ++) & 0x00FF);					\
}
#define MODBUS_DWORD_FROM_MSG(pMsg, nDWord) {				\
	nDWord = ((DWORD)((*pMsg ++) << 8) & 0x0000FF00);		\
	nDWord |= ((DWORD)((*pMsg ++) & 0x000000FF));			\
	nDWord |= ((DWORD)((*pMsg ++) << 24) & 0xFF000000);		\
	nDWord |= ((DWORD)((*pMsg ++) << 16) & 0x00FF0000);		\
}
/*
#define MODBUS_DWORD_FROM_MSG(pMsg, nDWord) {			\
	nDWord = (DWORD)((*pMsg ++) << 24) & 0xFF000000;	\
	nDWord |= (DWORD)((*pMsg ++) << 16) & 0x00FF0000;	\
	nDWord |= (DWORD)((*pMsg ++) << 8) & 0x0000FF00;	\
	nDWord |= (DWORD)((*pMsg ++) & 0x000000FF);			\
}*/

#define MODBUS_COIL_BYTE_POS(nOffSet)		((nOffSet & 0xFFF8) >> 3)
#define MODBUS_COIL_BIT_POS(nOffSet)		(nOffSet & 0x0007)
#define MODBUS_COIL_BIT_VAL(nOffSet)		(1 << MODBUS_COIL_BIT_POS(nOffSet))

#define MODBUS_COIL_BYTE_LEN(nCount)							\
	(BYTE)	(	(WORD)											\
		(	(	MODBUS_COIL_BYTE_POS(nCount) +					\
				((MODBUS_COIL_BIT_POS(nCount) == 0) ? 0 : 1)	\
			) &	0xFF)											\
	)										

#define MODBUS_FUNC_READ_COIL				0x01
#define MODBUS_FUNC_READ_STATE				0x02
#define MODBUS_FUNC_READ_HOLD_REG			0x03
#define MODBUS_FUNC_READ_INPUT_REG			0x04
#define	MODBUS_FUNC_FORCE_SINGLE_COIL		0x05
#define MODBUS_FUNC_PRESET_SINGLE_HOLD		0x06
#define	MODBUS_FUNC_FORCE_MULTI_COIL		0x0F
#define MODBUS_FUNC_PRESET_MULTI_HOLD		0x10
#define MODBUS_FUNC_READ_PRESET_MULTI_REG	0x17

#define MODBUS_REGISTER_COUNT	0x270F	/*9999*/
#define MODBUS_TCP_MBAP_LEN		7

	BOOL m_boolEthernetType;
	BOOL m_boolASCMode;
	BOOL m_boolMaster;
	BYTE m_byteSlaveNum;


	//	Variable for ModBus Register

	CModBusRegInfoArray* m_lparrayCoils;
	CModBusRegInfoArray* m_lparrayDiscrets;
	CModBusRegInfoArray* m_lparrayHolds;
	CModBusRegInfoArray* m_lparrayInputs;

#define MODBUS_REPLY_ERROR_MASK		0x80

	typedef struct tagMODBUS_SL_RX_REQUEST_INFO_ST
	{
		BYTE nFuncCode;
		WORD nReadAddr;
		WORD nReadCount;
		WORD nWriteAddr;
		WORD nWriteCount;
		MODBUS_MSG_ILLEGAL_TYPE enumErrState;
	}MODBUS_SL_RX_REQUEST_INFO_ST;
	MODBUS_SL_RX_REQUEST_INFO_ST m_stRequestInfo;

	enum MODBUS_RECV_MSG_PROC_STAGE
	{
		MODBUS_RECV_MSG_HEADER = 0,
		MODBUS_RECV_MSG_COMMAND,
		MODBUS_RECV_MSG_PARSING,
		MODBUS_RECV_MSG_RECVEND,
		MODBUS_RECV_MSG_EXTRACT,
		MODBUS_RECV_MSG_CHECK_CRC,
		MODBUS_RECV_MSG_CHECK_OK,
	};

#define MODBUS_MESSAGE_MAX_LEN	320
	typedef struct tagMODBUS_RECV_MSG_INFO_ST
	{
		WORD nTransactionId;
		WORD nRemainLen;
		WORD nCheckedLen;
		WORD nValueCount;
		WORD nValue1stId;

		BOOL bBusyFlag;

		char bufRxMsg[MODBUS_MESSAGE_MAX_LEN];

		MODBUS_RECV_MSG_PROC_STAGE enumProcStage;
	}MODBUS_RECV_MSG_INFO_ST;

	typedef struct tagMODBUS_SEND_MSG_INFO_ST
	{
		WORD nMsgLen;
		WORD nBufLen;
		char* bufTxMsg;
	}MODBUS_SEND_MSG_INFO_ST;

	MODBUS_RECV_MSG_INFO_ST m_stRxMsgInfo;
	MODBUS_SEND_MSG_INFO_ST m_stTxMsgInfo;

	CWordArray m_arrayForceErrAddr;
	CWordArray m_arrayReadErrAddr;
	CString m_stringDevSeriesName;

	CString m_stringTempTextStore;

public:
	BYTE SetModBusStationSpecNum(BYTE nNum);
	BOOL SetModbusPHYLinkType(BOOL bEthernet);
	WORD GetModBusCRCSumValue(char* lpczMsg, short nMsgLen);

	void SetModBusDevSeriesName(LPCTSTR lpszSeriesName);
	LPCTSTR GetModBusDevSeriesName(void);

	void ResetRecvErrorState(void);

protected:
	void InitRxStateStruct(void);

	MODBUS_REGIST_INFO_ST* GetRegisterInfoPointerFromRegAddr(
		CModBusRegInfoArray* lpRegInfoArray, WORD nRegAddr);
	CModBusRegInfoArray* GetModBusRegisterArrayByType(
		MODBUS_REG_TYPE_SORT nType, BOOL bCreate = TRUE);

public:
	WORD AppendModBusRegister(MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
		MODBUS_MSG_VALUE_TYPE enmuValueType, LPCTSTR lpszName);
	WORD InsertAtModBusRegister(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nInsertPos, WORD nAddr, 
		MODBUS_MSG_VALUE_TYPE enmuValueType, LPCTSTR lpszName);
	void RemoveAtModBusRegister(MODBUS_REG_TYPE_SORT enumRegType, WORD nRemovePos);
	void RemoveAllModbusRegister(MODBUS_REG_TYPE_SORT enumRegType);

protected:
	BOOL ParseRecvMessageCommonHeader(void);
	WORD ConstructTransMessageCommonHeader(void);
	WORD ConstructTransMessageComplete(void);

	void ConvertDataFromRegisterByValType(MODBUS_MSG_VALUE_TYPE enumValType, 
		DWORD nRegValue, LPVOID lpGetData);
	void ConvertDataFromRegisterByValTypeEx(
		MODBUS_MSG_VALUE_TYPE enumMsgType, DWORD nRegValue, 
		MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpGetData);

	void ConvertDataToRegisterByValType(MODBUS_MSG_VALUE_TYPE enumMsgType, 
		DWORD& nRegValue, LPVOID lpSetData);
	void ConvertDataToRegisterByValTypeEx(
		MODBUS_MSG_VALUE_TYPE enumMsgType, DWORD& nRegValue, 
		MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpSetData);
public:
	WORD GetModBusRegisterCount(MODBUS_REG_TYPE_SORT enumRegType);
	BOOL GetModBusRegisterProperty(MODBUS_REG_TYPE_SORT enumRegType, WORD nRegId, 
		WORD& nAddr, WORD& nValueType, CString& strName);
	BOOL GetModBusRegisterProperty(MODBUS_REG_TYPE_SORT enumRegType, WORD nRegId, 
		MODBUS_REGIST_INFO_ST& stRegisterInfo);

	BOOL GetModBusRegisterValueByAddr(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
				LPVOID lpGetData);
	BOOL GetModBusRegisterValueByAddrEx(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
				MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpGetData);
	BOOL GetModBusRegisterValueByIndex(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, 
				LPVOID lpGetData);
	BOOL GetModBusRegisterValueByIndexEx(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, 
				MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpGetData);

	LPCTSTR GetModBusRegisterValueStringByAddr(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, int nBoolType = 0);
	LPCTSTR GetModBusRegisterValueStringByIndex(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, int nBoolType = 0);

	BOOL SetModBusRegisterValueByAddr(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
				LPVOID lpGetData);
	BOOL SetModBusRegisterValueByIndex(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, 
				LPVOID lpGetData);
	BOOL SetModBusRegisterValueByAddrEx(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegAddr, 
				MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpSetData);
	BOOL SetModBusRegisterValueByIndexEx(
				MODBUS_REG_TYPE_SORT enumRegType, WORD nRegIndex, 
				MODBUS_MSG_VALUE_TYPE enumValType, LPVOID lpSetData);

	BOOL ReadRegisterInfoFromFile(LPCTSTR lpszFilePath);
	BOOL WriteRegisterInfoToFile(LPCTSTR lpszFilePath);

protected:
	BOOL ReadRegisterInfoFromFileBySort(MODBUS_REG_TYPE_SORT enumRegType, 
		int nRegAmount, LPCTSTR lpszFilePath);
	BOOL WriteRegisterInfoToFileBySort(MODBUS_REG_TYPE_SORT enumRegType, 
		LPCTSTR lpszFilePath);
	void CopyRegisterInfoArray(MODBUS_REG_TYPE_SORT enumRegType, 
		CModBusRegInfoArray* lparrayRegInfo);
public:
	COwnModBusDef& operator=(COwnModBusDef& clsSrcDef);

	BOOL GetRecvMessageIsBusy(void);
	BYTE GetModBusStationSpecNum(void);
	BOOL GetModbusPHYLinkTypeEthernet(void);

	long CheckModBusRegisterOverLayAddress(MODBUS_REG_TYPE_SORT enumRegType, 
		long* lpOverLayId2nd);
	long CheckModBusRegisterOverLayName(MODBUS_REG_TYPE_SORT enumRegType, 
		long* lpOverLayId2nd);
	static long CheckModBusRegOverLayAddrFromInfoArray(CModBusRegInfoArray* lpRegInfo, 
		WORD nChkAddr, WORD nChkType, long nExceptId = -1, long nStartId = 0);
	static long CheckModBusRegOverLayNameFromInfoArray(CModBusRegInfoArray* lpRegInfo, 
		LPCTSTR lpszChkName, long nExceptId = -1, long nStartId = 0);
	static long CheckModBusRegOverLayAddressInInfoArray(CModBusRegInfoArray* lpRegInfo, 
		long* lpOverLayId2nd);
	static long CheckModBusRegOverLayNameInInfoArray(CModBusRegInfoArray* lpRegInfo, 
		long* lpOverLayId2nd);
	static LPCTSTR GetModBusRegisterDataTypeString(
				MODBUS_MSG_VALUE_TYPE enumDataType, CString& strTypeDef);

	static void GetModBusRegisterDataTextFormat(CString& strValueText, 
				LPVOID lpData, MODBUS_MSG_VALUE_TYPE enumValType, int nBoolType);

	LPCTSTR GetModBusRegisterDataTypeString(
				MODBUS_MSG_VALUE_TYPE enumDataType);
	LPCTSTR GetModBusRegisterName(MODBUS_REG_TYPE_SORT enumRegSortType, WORD nRegId);
	WORD GetModBusRegisterDataType(MODBUS_REG_TYPE_SORT enumRegSortType, WORD nRegId);
	WORD GetModBusRegisterAddress(MODBUS_REG_TYPE_SORT enumRegSortType, WORD nRegId);

	int CheckModBusMessageCorrect(void);
protected:
	int m_intModBusMasterType;
public:
	int CheckModBusClassMasterType(void);
};
