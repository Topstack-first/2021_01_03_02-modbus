#include "StdAfx.h"
#include "OwnModBusSystem.h"

COwnModBusSystem::COwnModBusSystem(void)
{
}

COwnModBusSystem::~COwnModBusSystem(void)
{
	RemoveAllModBusDeviceInfo();
	RemoveAllModBusSeriesInfo();
}

WORD COwnModBusSystem::GetModBusSeriesCount(void)
{
	return (WORD)m_arrayModBusDefsPtr.GetCount();
}

COwnModBusDef* COwnModBusSystem::GetModBusSereisInfoPtr(WORD nSeriesId)
{
	WORD nSeriesCount = (WORD)m_arrayModBusDefsPtr.GetCount();
	if(nSeriesId < nSeriesCount)
		return m_arrayModBusDefsPtr.ElementAt(nSeriesId);

	return NULL;
}

void COwnModBusSystem::RemoveAllModBusSeriesInfo(void)
{
	WORD nSeriesCount = (WORD)m_arrayModBusDefsPtr.GetCount();
	for(WORD nSeriesId = 0; nSeriesId < nSeriesCount; nSeriesId ++)
	{
		COwnModBusDef* lpSeriesInfo = m_arrayModBusDefsPtr.ElementAt(nSeriesId);
		delete lpSeriesInfo;
	}
	m_arrayModBusDefsPtr.RemoveAll();
}

WORD COwnModBusSystem::AppenModBusSeriesInfo(COwnModBusDef* lpclsModBusSeries)
{
	COwnModBusDef* lpclsNewSeries = new COwnModBusDef;
	*lpclsNewSeries = *lpclsModBusSeries;
	return (WORD)m_arrayModBusDefsPtr.Add(lpclsNewSeries);
}

WORD COwnModBusSystem::GetModBusDeviceInfoCount(void)
{
	return (WORD)m_arrayModBusSysDev.GetCount();
}

MODBUS_SYSTEM_DEVICE_ST* COwnModBusSystem::GetModBusDeviceInfoPtr(WORD nDevId)
{
	WORD nDeviceCount = (WORD)m_arrayModBusSysDev.GetCount();
	if(nDevId < nDeviceCount)
	{
		return &(m_arrayModBusSysDev.ElementAt(nDevId));
	}
	return NULL;
}

WORD COwnModBusSystem::AppendModBusDeviceBaseInfo(WORD nSeriesId, BOOL bIsSlave, LPCTSTR lpszDevName)
{
	if(nSeriesId < (WORD)m_arrayModBusDefsPtr.GetCount())
	{
		MODBUS_SYSTEM_DEVICE_ST stModBusDevInfo;
		stModBusDevInfo.bSlaveDev = bIsSlave;
		stModBusDevInfo.strDeviceName = lpszDevName;
		stModBusDevInfo.nSeriesId = nSeriesId;

		if(bIsSlave == TRUE)
		{
			COwnModBusSlave* lpclsSlave = new COwnModBusSlave;
			*((COwnModBusDef*)lpclsSlave) = *(m_arrayModBusDefsPtr.ElementAt(nSeriesId));
			stModBusDevInfo.lpclsModBusInfo = lpclsSlave;
		}
		else
		{
			COwnModBusMaster* lpclsMaster = new COwnModBusMaster;
			*((COwnModBusDef*)lpclsMaster) = *(m_arrayModBusDefsPtr.ElementAt(nSeriesId));
			stModBusDevInfo.lpclsModBusInfo = lpclsMaster;
		}

		stModBusDevInfo.strSeriesName = 
			stModBusDevInfo.lpclsModBusInfo->GetModBusDevSeriesName();

		return (WORD)m_arrayModBusSysDev.Add(stModBusDevInfo);
	}
	return 0xFFFF;
}

void COwnModBusSystem::RemoveAtModBusDeviceInfo(WORD nDeviceId)
{
	WORD nDeviceCount = (WORD)m_arrayModBusSysDev.GetCount();
	if(nDeviceId < nDeviceCount)
	{
		MODBUS_SYSTEM_DEVICE_ST& stModBusDevInfo = 
			m_arrayModBusSysDev.ElementAt(nDeviceId);

		if(stModBusDevInfo.bSlaveDev == TRUE)
		{
			COwnModBusSlave* lpclsRemoveSlave = 
				(COwnModBusSlave*)stModBusDevInfo.lpclsModBusInfo;
			delete lpclsRemoveSlave;
		}
		else
		{
			COwnModBusMaster* lpclsRemoveMaster = 
				(COwnModBusMaster*)stModBusDevInfo.lpclsModBusInfo;
			delete lpclsRemoveMaster;
		}
		m_arrayModBusSysDev.RemoveAt(nDeviceId);
	}
}

void COwnModBusSystem::RemoveAllModBusDeviceInfo(void)
{
	WORD nDeviceCount = (WORD)m_arrayModBusSysDev.GetCount();
	for(WORD nDeviceId = 0; nDeviceId < nDeviceCount; nDeviceId ++)
	{
		MODBUS_SYSTEM_DEVICE_ST& stModBusDevInfo = 
			m_arrayModBusSysDev.ElementAt(nDeviceId);

		if(stModBusDevInfo.bSlaveDev == TRUE)
		{
			COwnModBusSlave* lpclsRemoveSlave = 
				(COwnModBusSlave*)stModBusDevInfo.lpclsModBusInfo;
			delete lpclsRemoveSlave;
		}
		else
		{
			COwnModBusMaster* lpclsRemoveMaster = 
				(COwnModBusMaster*)stModBusDevInfo.lpclsModBusInfo;
			delete lpclsRemoveMaster;
		}
	}
	m_arrayModBusSysDev.RemoveAll();
}

WORD COwnModBusSystem::InsertAtModBusDeviceBaseInfo(WORD nInsertId, WORD nSeriesId, BOOL bIsSlave, LPCTSTR lpszDevName)
{
	WORD nDeviceCount = (WORD)m_arrayModBusSysDev.GetCount();
	if(nInsertId <= nDeviceCount)
	{
		if(nSeriesId < (WORD)m_arrayModBusDefsPtr.GetCount())
		{
			MODBUS_SYSTEM_DEVICE_ST stModBusDevInfo;
			stModBusDevInfo.bSlaveDev = bIsSlave;
			stModBusDevInfo.strDeviceName = lpszDevName;
			stModBusDevInfo.nSeriesId = nSeriesId;

			if(bIsSlave == TRUE)
			{
				COwnModBusSlave* lpclsSlave = new COwnModBusSlave;
				*((COwnModBusDef*)lpclsSlave) = *(m_arrayModBusDefsPtr.ElementAt(nSeriesId));
				stModBusDevInfo.lpclsModBusInfo = lpclsSlave;
			}
			else
			{
				COwnModBusMaster* lpclsMaster = new COwnModBusMaster;
				*((COwnModBusDef*)lpclsMaster) = *(m_arrayModBusDefsPtr.ElementAt(nSeriesId));
				stModBusDevInfo.lpclsModBusInfo = lpclsMaster;
			}
			stModBusDevInfo.strSeriesName = 
				stModBusDevInfo.lpclsModBusInfo->GetModBusDevSeriesName();
			
			m_arrayModBusSysDev.InsertAt(nInsertId, stModBusDevInfo);
			return nInsertId;
		}
		return 0xFFFF;
	}
	return 0xFFFF;
}

BOOL COwnModBusSystem::ExchangeModBusDeviceInfoPostion(int nPosition1st, int nPosition2nd)
{
	if((nPosition1st < 0) || (nPosition2nd < 0))
		return FALSE;
	int nDevInfoCount = (int)m_arrayModBusSysDev.GetCount();
	
	if((nPosition1st >= nDevInfoCount) || (nPosition2nd >= nDevInfoCount))
		return FALSE;

	MODBUS_SYSTEM_DEVICE_ST stDev1st = m_arrayModBusSysDev.ElementAt(nPosition1st);
	m_arrayModBusSysDev.ElementAt(nPosition1st) = m_arrayModBusSysDev.ElementAt(nPosition2nd);
	m_arrayModBusSysDev.ElementAt(nPosition2nd) = stDev1st;
	return TRUE;
}

COwnModBusSystem& COwnModBusSystem::operator=(COwnModBusSystem& clsModBusSysSrc)
{
	//TODO: insert return statement here
	RemoveAllModBusDeviceInfo();
	RemoveAllModBusSeriesInfo();

	CModBusDefsPtrArray* lparraySeriesSrc = &(clsModBusSysSrc.m_arrayModBusDefsPtr);
	WORD nDeviceDefCount = (WORD)lparraySeriesSrc->GetCount();
	for(WORD nSereisId = 0; nSereisId < nDeviceDefCount; nSereisId ++)
	{
		COwnModBusDef* lpclsSeriesSrc = 
			lparraySeriesSrc->ElementAt(nSereisId);
		if(lpclsSeriesSrc != NULL)
		{
			COwnModBusDef* lpclsSeriesDst = new COwnModBusDef;

			*lpclsSeriesDst = *lpclsSeriesSrc;

			m_arrayModBusDefsPtr.Add(lpclsSeriesDst);
		}
		else
			m_arrayModBusDefsPtr.Add(NULL);
	}

	CModBusSysDevArray* lparraySysDevSrc = &(clsModBusSysSrc.m_arrayModBusSysDev);
	nDeviceDefCount = (WORD)lparraySysDevSrc->GetCount();

	for(WORD nDevId = 0; nDevId < nDeviceDefCount; nDevId ++)
	{
		MODBUS_SYSTEM_DEVICE_ST& stDevInfoSrc = lparraySysDevSrc->ElementAt(nDevId);
		MODBUS_SYSTEM_DEVICE_ST stDevInfoDst;

		stDevInfoDst = stDevInfoSrc;
		if(stDevInfoSrc.lpclsModBusInfo)
		{
			if(stDevInfoSrc.bSlaveDev == TRUE)
			{
				COwnModBusSlave* lpclsDevSlave = new COwnModBusSlave;
				*lpclsDevSlave = *((COwnModBusSlave*)stDevInfoSrc.lpclsModBusInfo);
				stDevInfoDst.lpclsModBusInfo = lpclsDevSlave;
			}
			else
			{
				COwnModBusMaster* lpclsDevMaster = new COwnModBusMaster;
				*lpclsDevMaster = *((COwnModBusMaster*)stDevInfoSrc.lpclsModBusInfo);
				stDevInfoDst.lpclsModBusInfo = lpclsDevMaster;
			}
		}

		m_arrayModBusSysDev.Add(stDevInfoDst);
	}

	return *this;
}

BOOL COwnModBusSystem::ReadModBusSystemConfigFile(LPCTSTR lpszConfPath)
{
	ReadModBusSeriesInfoFile(lpszConfPath);
	ReadModBusDeviceInfoFile(lpszConfPath);
	return TRUE;
}

BOOL COwnModBusSystem::ReadModBusSeriesInfoFile(LPCTSTR lpszConfPath)
{
	RemoveAllModBusSeriesInfo();

	CString strSeriesFile = lpszConfPath;
	strSeriesFile += _T("SeriesInfo.ini");
	LPCTSTR lpszSeriesFile = (LPCTSTR)strSeriesFile;

	CFile fileRead;

	if(fileRead.Open(lpszSeriesFile, CFile::modeRead) == FALSE)
		return FALSE;
	fileRead.Close();

	CString strAppName, strKeyName;
	const DWORD nProfileGetLen = 64;
	TCHAR tcszReadProfile[nProfileGetLen];
	LPCTSTR lpszDefault = _T("");

	strAppName = _T("SeriesInfo");
	strKeyName = _T("Amount");
	WORD nSeriesAmount = (WORD)::GetPrivateProfileInt(strAppName, strKeyName, 0, lpszSeriesFile);

	BOOL bRetVal = TRUE;

	for(WORD nSeriesId = 0; nSeriesId < nSeriesAmount; nSeriesId ++)
	{
		strSeriesFile.Format(_T("%sSeriesType%d.ini"), lpszConfPath, nSeriesId);
		lpszSeriesFile = (LPCTSTR)strSeriesFile;

		if(fileRead.Open(lpszSeriesFile, CFile::modeRead) == FALSE)
		{
			bRetVal = FALSE;
			break;
		}
		fileRead.Close();

		strAppName = _T("SeriesInfo");
		strKeyName = _T("Name");

		COwnModBusDef* lpclsModBusSeries = new COwnModBusDef;
		
		::GetPrivateProfileString(strAppName, strKeyName, 
			lpszDefault, tcszReadProfile, nProfileGetLen, lpszSeriesFile);
		lpclsModBusSeries->SetModBusDevSeriesName(tcszReadProfile);

		lpclsModBusSeries->ReadRegisterInfoFromFile(strSeriesFile);

		m_arrayModBusDefsPtr.Add(lpclsModBusSeries);
	}

	return TRUE;
}

BOOL COwnModBusSystem::ReadModBusDeviceInfoFile(LPCTSTR lpszConfPath)
{
	RemoveAllModBusDeviceInfo();

	CString strDeviceFile = lpszConfPath;
	strDeviceFile += _T("DeviceInfo.ini");
	LPCTSTR lpszDeviceFile = (LPCTSTR)strDeviceFile;

	CString strAppName, strKeyName;
	LPCTSTR lpszAppName;

	const DWORD nProfileGetLen = 64;
	TCHAR tcszReadProfile[nProfileGetLen];
	LPCTSTR lpszDefault = _T("");

	strAppName = _T("DeviceInfo");
	strKeyName = _T("Amount");

	WORD nDeviceAmount = (WORD)::GetPrivateProfileInt(strAppName, strKeyName, 0, lpszDeviceFile);

	MODBUS_SYSTEM_DEVICE_ST stSysDevInfo;

	BYTE nStationNum;
	BOOL bSlaveLink, bTCPType;
	WORD nSeriesId, nSeriesAmount;

	nSeriesAmount = (WORD)m_arrayModBusDefsPtr.GetCount();

	for(WORD nDeviceId = 0; nDeviceId < nDeviceAmount; nDeviceId ++)
	{
		strDeviceFile.Format(_T("%sDeviceType%d.ini"), lpszConfPath, nDeviceId);
		lpszDeviceFile = (LPCTSTR)strDeviceFile;

		lpszAppName = _T("Specification");
		::GetPrivateProfileString(lpszAppName, _T("DevName"), lpszDefault, 
			tcszReadProfile, nProfileGetLen, lpszDeviceFile);

		stSysDevInfo.strDeviceName = tcszReadProfile;

		nStationNum = (BYTE)::GetPrivateProfileInt(lpszAppName, _T("IdendifyNum"), 0, lpszDeviceFile);
		bTCPType = (BOOL)::GetPrivateProfileInt(lpszAppName, _T("TCPMode"), 0, lpszDeviceFile);
		::GetPrivateProfileString(lpszAppName, _T("SeriesName"), lpszDefault, 
			tcszReadProfile, nProfileGetLen, lpszDeviceFile);
		stSysDevInfo.strSeriesName = tcszReadProfile;

		nSeriesId = (WORD)::GetPrivateProfileInt(lpszAppName, _T("SeriesId"), 0, lpszDeviceFile);
		stSysDevInfo.nSeriesId = nSeriesId;
		
		bSlaveLink = (BOOL)::GetPrivateProfileInt(lpszAppName, _T("SlaveMode"), 0, lpszDeviceFile);
		stSysDevInfo.bSlaveDev = bSlaveLink;

		if(bSlaveLink == FALSE)
		{
			COwnModBusMaster* lpclsMasterDev = new COwnModBusMaster;

			lpclsMasterDev->ReadModBusAccessInfoFile(lpszDeviceFile);
			stSysDevInfo.lpclsModBusInfo = lpclsMasterDev;
		}
		else
		{
			COwnModBusSlave* lpclsSlaveDev = new COwnModBusSlave;
			stSysDevInfo.lpclsModBusInfo = lpclsSlaveDev;
		}
		
		if(nSeriesAmount > nSeriesId)
		{
			COwnModBusDef* lpclsModBusSeries = m_arrayModBusDefsPtr.ElementAt(nSeriesId);
			if(lpclsModBusSeries)
				*(stSysDevInfo.lpclsModBusInfo) = *lpclsModBusSeries;
		}
		stSysDevInfo.lpclsModBusInfo->SetModbusPHYLinkType(bTCPType);
		stSysDevInfo.lpclsModBusInfo->SetModBusStationSpecNum(nStationNum);

		m_arrayModBusSysDev.Add(stSysDevInfo);
	}
	return TRUE;
}

BOOL COwnModBusSystem::WriteModBusSystemConfigFile(LPCTSTR lpszConfPath)
{
	WriteModBusSeriesInfoFile(lpszConfPath);
	WriteModBusDeviceInfoFile(lpszConfPath);

	return TRUE;
}

BOOL COwnModBusSystem::WriteModBusSeriesInfoFile(LPCTSTR lpszConfPath)
{
	CString strSeriesFile = lpszConfPath;
	strSeriesFile += _T("SeriesInfo.ini");
	LPCTSTR lpszSeriesFile = (LPCTSTR)strSeriesFile;

	CFile fileWrite;
	if(fileWrite.Open(lpszSeriesFile, CFile::modeWrite | CFile::modeCreate) == FALSE)
		return FALSE;
	fileWrite.Close();

	CString strAppName, strKeyName, strKeyVal;

	strAppName = _T("SeriesInfo");
	strKeyName = _T("Amount");
	WORD nSeriesAmount = (WORD)m_arrayModBusDefsPtr.GetCount();
	strKeyVal.Format(_T("%u"), nSeriesAmount);
	::WritePrivateProfileString(strAppName, strKeyName, strKeyVal, lpszSeriesFile);

	BOOL bRetVal = TRUE;
	for(WORD nSeriesId = 0; nSeriesId < nSeriesAmount; nSeriesId ++)
	{
		strSeriesFile.Format(_T("%sSeriesType%d.ini"), lpszConfPath, nSeriesId);
		lpszSeriesFile = (LPCTSTR)strSeriesFile;

		if(fileWrite.Open(lpszSeriesFile, CFile::modeWrite | CFile::modeCreate) == FALSE)
		{
			bRetVal = FALSE;
			break;
		}
		fileWrite.Close();

		strAppName = _T("SeriesInfo");
		strKeyName = _T("Name");

		COwnModBusDef* lpclsModBusSeries = m_arrayModBusDefsPtr.ElementAt(nSeriesId);
		
		if(lpclsModBusSeries)
		{
			::WritePrivateProfileString(strAppName, strKeyName, 
				lpclsModBusSeries->GetModBusDevSeriesName(), lpszSeriesFile);

			lpclsModBusSeries->WriteRegisterInfoToFile(strSeriesFile);
		}
	}

	return bRetVal;
}

BOOL COwnModBusSystem::WriteModBusDeviceInfoFile(LPCTSTR lpszConfPath)
{
	CString strDeviceFile = lpszConfPath;
	strDeviceFile += _T("DeviceInfo.ini");
	LPCTSTR lpszDeviceFile = (LPCTSTR)strDeviceFile;

	CString strAppName, strKeyName, strKeyVal;
	LPCTSTR lpszAppName;

	CFile fileWrite;
	if(fileWrite.Open(lpszDeviceFile, CFile::modeWrite | CFile::modeCreate) == FALSE)
		return FALSE;
	fileWrite.Close();

	strAppName = _T("DeviceInfo");
	strKeyName = _T("Amount");

	WORD nDeviceAmount = (WORD)m_arrayModBusSysDev.GetCount();
	strKeyVal.Format(_T("%u"), nDeviceAmount);

	::WritePrivateProfileString(strAppName, strKeyName, strKeyVal, lpszDeviceFile);

	BOOL bRetVal = TRUE;
	for(WORD nDeviceId = 0; nDeviceId < nDeviceAmount; nDeviceId ++)
	{
		strDeviceFile.Format(_T("%sDeviceType%d.ini"), lpszConfPath, nDeviceId);
		lpszDeviceFile = (LPCTSTR)strDeviceFile;

		if(fileWrite.Open(lpszDeviceFile, CFile::modeWrite | CFile::modeCreate) == FALSE)
		{
			bRetVal = FALSE;
			break;
		}
		fileWrite.Close();

		MODBUS_SYSTEM_DEVICE_ST& stSysDevInfo = m_arrayModBusSysDev.ElementAt(nDeviceId);

		lpszAppName = _T("Specification");
		::WritePrivateProfileString(lpszAppName, _T("DevName"), 
			stSysDevInfo.strDeviceName, lpszDeviceFile);

		if(stSysDevInfo.lpclsModBusInfo)
		{
			COwnModBusDef* lpclsModBusSeries = stSysDevInfo.lpclsModBusInfo;
			strKeyVal.Format(_T("%u"), lpclsModBusSeries->GetModBusStationSpecNum());
			::WritePrivateProfileString(lpszAppName, _T("IdendifyNum"), strKeyVal, lpszDeviceFile);

			strKeyVal = (lpclsModBusSeries->GetModbusPHYLinkTypeEthernet() == FALSE) ? 
				_T("0") : _T("1");
			::WritePrivateProfileString(lpszAppName, _T("TCPMode"), strKeyVal, lpszDeviceFile);
		
			::WritePrivateProfileString(lpszAppName, _T("SeriesName"), 
				lpclsModBusSeries->GetModBusDevSeriesName(), lpszDeviceFile);
		}

		strKeyVal.Format(_T("%u"), stSysDevInfo.nSeriesId);
		::WritePrivateProfileString(lpszAppName, _T("SeriesId"), strKeyVal, lpszDeviceFile);

		strKeyVal = (stSysDevInfo.bSlaveDev == FALSE) ? _T("0") : _T("1");
		WritePrivateProfileString(lpszAppName, _T("SlaveMode"), strKeyVal, lpszDeviceFile);

		if(stSysDevInfo.bSlaveDev == FALSE)
		{
			COwnModBusMaster* lpclsMasterDev = (COwnModBusMaster*)stSysDevInfo.lpclsModBusInfo;

			if(lpclsMasterDev)
				lpclsMasterDev->WriteModBusAccessInfoFile(lpszDeviceFile);
		}
	}
	return TRUE;
}
