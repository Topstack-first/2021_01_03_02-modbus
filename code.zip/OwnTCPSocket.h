#pragma once

// COwnTCPSocket command target

class COwnTCPSocket : public CSocket
{
public:
	COwnTCPSocket();
	virtual ~COwnTCPSocket();
protected:

	typedef BOOL (funcOwnSocketCallBack)(CSocket* lpThis, LPVOID lpInterface);
	LPVOID m_lpvoidEthernetInterface;
	LPVOID m_lpvoidOnAcceptInterface;
	LPVOID m_lpvoidOnReceiveInterface;
	LPVOID m_lpvoidOnCloseInterface;

	typedef struct tagOWN_IPADDR_SYS_CONF_ST
	{
		CString strAdapterName;
		CString strDescription;
		CStringArray* lparrayAddr;
		CStringArray* lparrayMask;
	}OWN_IPADDR_SYS_CONF_ST;

	typedef CArray<OWN_IPADDR_SYS_CONF_ST, OWN_IPADDR_SYS_CONF_ST> CIPAdapterInfoArray;
	CIPAdapterInfoArray m_arrayAdaptorInfo;

	BOOL m_boolConnected;
public:
	virtual void OnAccept(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void Close();

protected:
	funcOwnSocketCallBack* m_ptrfuncOnAcceptCallBack;
	funcOwnSocketCallBack* m_ptrfuncOnReceiveCallBack;
	funcOwnSocketCallBack* m_ptrfuncOnColseCallBack;

public:

	void SetOnAcceptCallBack(funcOwnSocketCallBack* lpOnAcceptFunc, LPVOID lpInterface = NULL);
	void SetOnReceiveCallBack(funcOwnSocketCallBack* lpOnRecvFunc, LPVOID lpInterface = NULL);
	void SetEthernetInterface(LPVOID lpInterface);
	void SetOnCloseCallBack(funcOwnSocketCallBack* lpOnCloseFunc, LPVOID lpInterface);

	void RefreshIPAddressSysConf(void);
	void RemoveIPAdapterSysConfInfo(void);

	INT_PTR GetIPAdaptorSysConfCount(void);
	LPCTSTR GetIPAdaptorConfName(INT_PTR nAdaptorId);
	LPCTSTR GetIpAdaptorConfDescription(INT_PTR nAdaptorId);
	INT_PTR GetIpAddressCountLinkAdaptor(INT_PTR nAdaptorId);
	INT_PTR GetIpMaskCountLinkAdaptor(INT_PTR nAdaptorId);
	LPCTSTR GetIPAddressLinkAdaptor(INT_PTR nAdaptorId, INT_PTR nAddrId);
	LPCTSTR GetIPMaskLinkAdaptor(INT_PTR nAdaptorId, INT_PTR nMaskId);
	INT_PTR GetIPAddrCountSysConf(void);
	LPCTSTR GetIPAddressSysConf(INT_PTR nAddrId);
	BOOL GetSocketActiveState(void);
	BOOL CheckPeerHostAddressEnable(LPCTSTR lpszIPAddr);
	BOOL CheckPeerHostPortEnable(LPCTSTR lpszAddr, UINT nPort);
};

