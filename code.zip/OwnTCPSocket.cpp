// OwnTCPSocket.cpp : implementation file
//

#include "stdafx.h"
#include "OwnTCPSocket.h"

#include "Iphlpapi.h"
#pragma comment(lib, "Iphlpapi")

// COwnTCPSocket

COwnTCPSocket::COwnTCPSocket()
: m_boolConnected(FALSE)
{
//	m_boolServerFlag = FALSE;

	m_ptrfuncOnAcceptCallBack = NULL;
	m_ptrfuncOnReceiveCallBack = NULL;
	m_ptrfuncOnColseCallBack = NULL;

	m_lpvoidEthernetInterface = NULL;
	m_lpvoidOnAcceptInterface = NULL;
	m_lpvoidOnReceiveInterface = NULL;
	m_lpvoidOnCloseInterface = NULL;
}

COwnTCPSocket::~COwnTCPSocket()
{
	if(m_boolConnected)
	{
		if(IsBlocking())
			CancelBlockingCall();
		Close();
	}

	RemoveIPAdapterSysConfInfo();
}


// COwnTCPSocket member functions

void COwnTCPSocket::OnAccept(int nErrorCode)
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_ptrfuncOnAcceptCallBack != NULL)
	{
		LPVOID lpInterface = (m_lpvoidOnAcceptInterface) ? 
			m_lpvoidOnAcceptInterface : m_lpvoidEthernetInterface;
		(*m_ptrfuncOnAcceptCallBack)(this, lpInterface);
	}
	CSocket::OnAccept(nErrorCode);
}

void COwnTCPSocket::OnReceive(int nErrorCode)
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_ptrfuncOnReceiveCallBack != NULL)
	{
		LPVOID lpInterface = (m_lpvoidOnReceiveInterface) ? 
			m_lpvoidOnReceiveInterface : m_lpvoidEthernetInterface;
		(*m_ptrfuncOnReceiveCallBack)(this, lpInterface);
	}
	CSocket::OnReceive(nErrorCode);
}

void COwnTCPSocket::OnClose(int nErrorCode)
{
	// TODO: Add your specialized code here and/or call the base class

	m_boolConnected = FALSE;
	if(m_ptrfuncOnColseCallBack)
	{
		LPVOID lpInterface = (m_lpvoidOnCloseInterface) ? 
			m_lpvoidOnCloseInterface : m_lpvoidEthernetInterface;
		(*m_ptrfuncOnColseCallBack)(this, lpInterface);
	}

	CSocket::OnClose(nErrorCode);

}

void COwnTCPSocket::Close()
{
	m_boolConnected = FALSE;
	CSocket::Close();
}

void COwnTCPSocket::SetOnAcceptCallBack(funcOwnSocketCallBack* lpOnAcceptFunc, LPVOID lpInterface)
{
	m_ptrfuncOnAcceptCallBack = lpOnAcceptFunc;
	m_lpvoidOnAcceptInterface = lpInterface;
}

void COwnTCPSocket::SetOnReceiveCallBack(funcOwnSocketCallBack* lpOnRecvFunc, LPVOID lpInterface)
{
	m_ptrfuncOnReceiveCallBack = lpOnRecvFunc;
	m_lpvoidOnReceiveInterface = lpInterface;
}

void COwnTCPSocket::SetOnCloseCallBack(funcOwnSocketCallBack* lpOnCloseFunc, LPVOID lpInterface)
{
	m_ptrfuncOnColseCallBack = lpOnCloseFunc;
	m_lpvoidOnCloseInterface = lpInterface;
}

void COwnTCPSocket::SetEthernetInterface(LPVOID lpInterface)
{
	m_lpvoidEthernetInterface = lpInterface;
}

void COwnTCPSocket::RefreshIPAddressSysConf(void)
{
	RemoveIPAdapterSysConfInfo();

	PIP_ADAPTER_INFO pAdapterInfo;
	ULONG uGetSize = sizeof(IP_ADAPTER_INFO);
	pAdapterInfo = (PIP_ADAPTER_INFO)malloc(uGetSize);

	if(GetAdaptersInfo(pAdapterInfo, &uGetSize) == ERROR_BUFFER_OVERFLOW)
	{
		free(pAdapterInfo);
		pAdapterInfo = (PIP_ADAPTER_INFO)malloc(uGetSize);
	}

	if(GetAdaptersInfo(pAdapterInfo, &uGetSize) == NO_ERROR)
	{
		UINT nIpAddrId = 0;
		PIP_ADAPTER_INFO pAdapterNext = pAdapterInfo;
		CString strdescription;
		CString strIpAddr;
		CString strAdapterName;

		HKEY tempMachineHardWareKey;
		CString strRegRootItem = _T("SYSTEM\\CurrentControlSet\\Services");
		CString strRegBranch;
		const DWORD nValueNameLen = 32767;

		DWORD dwNameLen, dwDataLen;
		TCHAR tcszValueName[nValueNameLen];
		TCHAR tszValueData[nValueNameLen];

		while(pAdapterNext != NULL)
		{
			strdescription = pAdapterNext->Description;
			strAdapterName = pAdapterNext->AdapterName;

			OWN_IPADDR_SYS_CONF_ST stAdaptorInfo;

			stAdaptorInfo.strAdapterName = strAdapterName;
			stAdaptorInfo.strDescription = strdescription;
			
			CStringArray* lpArrayAddr =  new CStringArray;
			CStringArray* lpArrayMask =  new CStringArray;
			stAdaptorInfo.lparrayAddr = lpArrayAddr;
			stAdaptorInfo.lparrayMask = lpArrayMask;

		//	strRegBranch.Format(_T("%s\\%s\\Parameters\\Tcpip"), strRegRootItem, strAdapterName);
			strRegBranch.Format(_T("%s\\Tcpip\\Parameters\\Interfaces\\%s"), strRegRootItem, strAdapterName);
			DWORD dwRegValId = 0;
			DWORD dwDataType;
			if(RegOpenKey(HKEY_LOCAL_MACHINE, strRegBranch, &tempMachineHardWareKey) == 0)
			{
				dwDataLen = dwNameLen = nValueNameLen;
				dwDataLen *= sizeof(TCHAR);
				tcszValueName[0] = 0x00;
				while(RegEnumValue(	tempMachineHardWareKey, 
									dwRegValId, 	
									tcszValueName, 
									&dwNameLen, 
									NULL, 
									&dwDataType, //	REG_MULT_SZ, 
									(LPBYTE)tszValueData, 
									&dwDataLen
									) == ERROR_SUCCESS)
				{
					if(wcscmp(tcszValueName, _T("IPAddress")) == 0)
					{
					//	dwDataLen /= sizeof(TCHAR);

						TCHAR* tcszIpAddr = tszValueData;
						while(wcslen(tcszIpAddr) != 0)
						{
							nIpAddrId ++;
							strIpAddr = tcszIpAddr;

							lpArrayAddr->Add(strIpAddr);

							tcszIpAddr += wcslen(tcszIpAddr);
							tcszIpAddr ++;
						}
					}

					if(wcscmp(tcszValueName, _T("SubnetMask")) == 0)
					{
						TCHAR* tcszIpAddr = tszValueData;
						while(wcslen(tcszIpAddr) != 0)
						{
							nIpAddrId ++;
							strIpAddr = tcszIpAddr;

							lpArrayMask->Add(strIpAddr);

							tcszIpAddr += wcslen(tcszIpAddr);
							tcszIpAddr ++;
						}
					}
					dwDataLen = dwNameLen = nValueNameLen;
					dwDataLen *= sizeof(TCHAR);
					dwRegValId ++;
				}
				RegCloseKey(tempMachineHardWareKey);
			}
			else
			{
				IP_ADDR_STRING* lpstIpAddrList = &pAdapterNext->IpAddressList;
				while(lpstIpAddrList)
				{
					strIpAddr.Format(_T("%d"), nIpAddrId + 1);

					strIpAddr = lpstIpAddrList->IpAddress.String;
					lpArrayAddr->Add(strIpAddr);

					strIpAddr = lpstIpAddrList->IpMask.String;
					lpArrayMask->Add(strIpAddr);

					lpstIpAddrList = lpstIpAddrList->Next;
					nIpAddrId ++;
				}
			}

			m_arrayAdaptorInfo.Add(stAdaptorInfo);

			pAdapterNext = pAdapterNext->Next;
		}
	}
}

void COwnTCPSocket::RemoveIPAdapterSysConfInfo(void)
{
	INT_PTR nAdapterAmount = m_arrayAdaptorInfo.GetCount();
	for(INT_PTR nAdapterId = 0; nAdapterId ++; nAdapterId ++)
	{
		OWN_IPADDR_SYS_CONF_ST& stAdaptorInfo = 
			m_arrayAdaptorInfo.ElementAt(nAdapterId);

		CStringArray* lpAddrSpec;
		if(stAdaptorInfo.lparrayAddr)
		{
			lpAddrSpec = stAdaptorInfo.lparrayAddr;
			stAdaptorInfo.lparrayAddr = NULL;

			lpAddrSpec->RemoveAll();
			delete lpAddrSpec;
		}

		if(stAdaptorInfo.lparrayMask)
		{
			lpAddrSpec = stAdaptorInfo.lparrayMask;
			stAdaptorInfo.lparrayMask = NULL;

			lpAddrSpec->RemoveAll();
			delete lpAddrSpec;
		}
	}
	m_arrayAdaptorInfo.RemoveAll();
}

INT_PTR COwnTCPSocket::GetIPAdaptorSysConfCount(void)
{
	return m_arrayAdaptorInfo.GetCount();
}

LPCTSTR COwnTCPSocket::GetIPAdaptorConfName(INT_PTR nAdaptorId)
{
	if(nAdaptorId < m_arrayAdaptorInfo.GetCount())
	{
		return (LPCTSTR)(m_arrayAdaptorInfo.ElementAt(nAdaptorId).strAdapterName);
	}
	return NULL;
}

LPCTSTR COwnTCPSocket::GetIpAdaptorConfDescription(INT_PTR nAdaptorId)
{
	if(nAdaptorId < m_arrayAdaptorInfo.GetCount())
	{
		return (LPCTSTR)(m_arrayAdaptorInfo.ElementAt(nAdaptorId).strDescription);
	}
	return NULL;
}

INT_PTR COwnTCPSocket::GetIpAddressCountLinkAdaptor(INT_PTR nAdaptorId)
{
	if(nAdaptorId < m_arrayAdaptorInfo.GetCount())
	{
		CStringArray* lpStringArray = 
			m_arrayAdaptorInfo.ElementAt(nAdaptorId).lparrayAddr;

		if(lpStringArray == NULL)
			return 0;

		return lpStringArray->GetCount();
	}
	return 0;
}

INT_PTR COwnTCPSocket::GetIpMaskCountLinkAdaptor(INT_PTR nAdaptorId)
{
	if(nAdaptorId < m_arrayAdaptorInfo.GetCount())
	{
		CStringArray* lpStringArray = 
			m_arrayAdaptorInfo.ElementAt(nAdaptorId).lparrayMask;

		if(lpStringArray == NULL)
			return 0;

		return lpStringArray->GetCount();
	}
	return 0;
}

LPCTSTR COwnTCPSocket::GetIPAddressLinkAdaptor(INT_PTR nAdaptorId, INT_PTR nAddrId)
{
	if(nAdaptorId < m_arrayAdaptorInfo.GetCount())
	{
		CStringArray* lpStringArray = 
			m_arrayAdaptorInfo.ElementAt(nAdaptorId).lparrayAddr;

		if((lpStringArray == NULL) || (nAddrId >= lpStringArray->GetCount()))
			return NULL;


		return (LPCTSTR)(lpStringArray->ElementAt(nAddrId));
	}
	return NULL;
}

LPCTSTR COwnTCPSocket::GetIPMaskLinkAdaptor(INT_PTR nAdaptorId, INT_PTR nMaskId)
{
	if(nAdaptorId < m_arrayAdaptorInfo.GetCount())
	{
		CStringArray* lpStringArray = 
			m_arrayAdaptorInfo.ElementAt(nAdaptorId).lparrayMask;

		if((lpStringArray == NULL) || (nMaskId >= lpStringArray->GetCount()))
			return NULL;


		return (LPCTSTR)(lpStringArray->ElementAt(nMaskId));
	}
	return NULL;
}

INT_PTR COwnTCPSocket::GetIPAddrCountSysConf(void)
{
	INT_PTR nAdaptorCount = m_arrayAdaptorInfo.GetCount();
	INT_PTR nRetTotalCount = 0;
	for(INT_PTR nAdaptorId = 0; nAdaptorId <nAdaptorCount; nAdaptorId ++)
	{
		nRetTotalCount += GetIpAddressCountLinkAdaptor(nAdaptorId);
	}
	return nRetTotalCount;
}

LPCTSTR COwnTCPSocket::GetIPAddressSysConf(INT_PTR nAddrId)
{
	INT_PTR nAdaptorCount = m_arrayAdaptorInfo.GetCount();
	INT_PTR nCheckedCount = 0;
	LPCTSTR lpszRetAddr = NULL;

	for(INT_PTR nAdaptorId = 0; nAdaptorId <nAdaptorCount; nAdaptorId ++)
	{
		OWN_IPADDR_SYS_CONF_ST& stAdaptorInfo = 
			m_arrayAdaptorInfo.ElementAt(nAdaptorId);
		CStringArray* lpStringArray = stAdaptorInfo.lparrayAddr;

		INT_PTR nIndivCount = (lpStringArray == NULL) ? 0 : lpStringArray->GetCount();

		if(nAddrId < nCheckedCount + nIndivCount)
		{
			lpszRetAddr = (LPCTSTR)(lpStringArray->ElementAt(nAddrId - nCheckedCount));
			break;
		}
		nCheckedCount += nIndivCount;
	}
	return lpszRetAddr;
}

BOOL COwnTCPSocket::GetSocketActiveState(void)
{
	return m_boolConnected;
}

BOOL COwnTCPSocket::CheckPeerHostAddressEnable(LPCTSTR lpszIPAddr)
{
	CStringA strIPAddrA;
	strIPAddrA = lpszIPAddr;
	HRESULT hresult;
	ULONG pulMac[2];
	ULONG ulLen;

	DWORD ipAddr = inet_addr ((LPCSTR)strIPAddrA);

	memset (pulMac, 0xff, sizeof (pulMac));
	ulLen = 6;

	hresult = SendARP (ipAddr, 0, pulMac, &ulLen);
	
	if(hresult == NO_ERROR)
		return TRUE;
	//socket  = INVALID_SOCKET;
	return FALSE;
}

BOOL COwnTCPSocket::CheckPeerHostPortEnable(LPCTSTR lpszAddr, UINT nPort)
{
	SOCKET sockTest = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	BOOL bRetVal = FALSE;
	if(sockTest != INVALID_SOCKET)
	{
		CStringA strIpAddr;
		strIpAddr = lpszAddr;

		sockaddr_in clientService; 
		clientService.sin_family = AF_INET;
		clientService.sin_addr.s_addr = inet_addr(strIpAddr);
		clientService.sin_port = htons(nPort);

		if(connect(sockTest, (SOCKADDR*)&clientService, 
					sizeof(clientService)) != SOCKET_ERROR) 
		{
			bRetVal = TRUE;
		}
		closesocket(sockTest);
	}
	return bRetVal;
}
