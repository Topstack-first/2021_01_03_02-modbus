#include "StdAfx.h"
#include "OwnModBusSlave.h"

COwnModBusSlave::COwnModBusSlave(void)
{
	m_intModBusMasterType = MODBUS_CLASS_TYPE_SLAVE;
}

COwnModBusSlave::~COwnModBusSlave(void)
{
}

BOOL COwnModBusSlave::ParseRequestMessage(char* lpRequestMsg, WORD nRxLen)
{
	char* lpRxCombBuf	= m_stRxMsgInfo.bufRxMsg;
	WORD& nRemainLen	= m_stRxMsgInfo.nRemainLen;
	WORD& nCheckedLen	= m_stRxMsgInfo.nCheckedLen;
	MODBUS_RECV_MSG_PROC_STAGE& enumRxStage = m_stRxMsgInfo.enumProcStage;

	memcpy(lpRxCombBuf + nRemainLen, lpRequestMsg, nRxLen);

	m_stRxMsgInfo.nRemainLen += nRxLen;

	BOOL bMsgCorrect = TRUE;
	BOOL bNextParse = (nRemainLen > nCheckedLen) ? TRUE : FALSE;

	while(bMsgCorrect & bNextParse)
	{
		switch(enumRxStage)
		{
		case MODBUS_RECV_MSG_HEADER:
			m_arrayForceErrAddr.RemoveAll();
			m_arrayReadErrAddr.RemoveAll();
			m_stRxMsgInfo.bBusyFlag = TRUE;
			m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_NONE;
			bMsgCorrect = ParseRecvMessageCommonHeader();
			break;

		case MODBUS_RECV_MSG_COMMAND:
			bMsgCorrect = ParseRequestMsgGetCommandType();
			break;

		case MODBUS_RECV_MSG_PARSING:
			bMsgCorrect = ParseRequestMsgParsingFunction();
			break;

		case MODBUS_RECV_MSG_RECVEND:
			bMsgCorrect = ParseRequestMsgWaitEndChar();
			if(enumRxStage == MODBUS_RECV_MSG_EXTRACT)
				bNextParse = TRUE;
			break;

		case MODBUS_RECV_MSG_EXTRACT:
			bMsgCorrect = ExtractReadDataFromRequestMsg();
			bMsgCorrect = TRUE;
			InitRxStateStruct();
			bNextParse = FALSE;
			break;

		default:
			bMsgCorrect = FALSE;
			break;
		}

		if((bMsgCorrect == TRUE) && (bNextParse == TRUE) && 
			(enumRxStage != MODBUS_RECV_MSG_EXTRACT))
		{
			bNextParse = (nRemainLen > nCheckedLen) ? TRUE : FALSE;
		}
	}

	if(bMsgCorrect == FALSE)
	{
		InitRxStateStruct();
	}

	return bMsgCorrect;
}

BOOL COwnModBusSlave::ParseRequestMsgGetCommandType(void)
{
	BOOL bRetVal = TRUE;
	WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;
	if(m_stRxMsgInfo.nRemainLen >= nCheckedLen + 1)
	{
		char *lpCommandBuf = m_stRxMsgInfo.bufRxMsg;
		lpCommandBuf += nCheckedLen;
		m_stRequestInfo.nFuncCode = *(BYTE*)lpCommandBuf;

		nCheckedLen ++;
		m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_PARSING;
		m_stRxMsgInfo.nValue1stId = 0;
	}
	return bRetVal;
}

BOOL COwnModBusSlave::ParseRequestMsgParsingFunction(void)
{
	BOOL bRetVal = TRUE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;

	if((nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_SINGLE_HOLD) ||
		(nRequestType == MODBUS_FUNC_READ_COIL) ||
		(nRequestType == MODBUS_FUNC_READ_STATE) ||
		(nRequestType == MODBUS_FUNC_READ_HOLD_REG) ||
		(nRequestType == MODBUS_FUNC_READ_INPUT_REG))
	{
		m_stRxMsgInfo.nValue1stId = m_stRxMsgInfo.nCheckedLen;
		m_stRxMsgInfo.nValueCount = 4;
		m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_RECVEND;
	}
	else if((nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_MULTI_HOLD))
	{
		WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;
		WORD& nValue1stId = m_stRxMsgInfo.nValue1stId;

		if(nValue1stId == 0)
			nValue1stId = nCheckedLen;
		char* lpMsgBuf = m_stRxMsgInfo.bufRxMsg;
		nCheckedLen = m_stRxMsgInfo.nRemainLen;

		if(nCheckedLen >= nValue1stId + 5)
		{
			lpMsgBuf += (nValue1stId + 5);
			m_stRxMsgInfo.nValueCount = (WORD)(*lpMsgBuf);
			m_stRxMsgInfo.nValueCount += 5;

			m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_RECVEND;
		}
	}
	else
	{
		m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_FUNC;
		bRetVal = FALSE;
	}
	return bRetVal;
}

BOOL COwnModBusSlave::ParseRequestMsgWaitEndChar(void)
{
	BOOL bRetVal = TRUE;
	WORD nTotalLen = m_stRxMsgInfo.nValue1stId + m_stRxMsgInfo.nValueCount;
	if(m_boolEthernetType == TRUE)
	{
		if(m_stRxMsgInfo.nRemainLen >= nTotalLen)
			m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_EXTRACT;
	}
	else
	{
		if(m_stRxMsgInfo.nRemainLen >= nTotalLen + 2)
		{
			char* lpMsgBuf = m_stRxMsgInfo.bufRxMsg;
			WORD nCRCVal = GetModBusCRCSumValue(lpMsgBuf, nTotalLen);
			lpMsgBuf += nTotalLen;
			if(nCRCVal == *(WORD*)lpMsgBuf)
			{
				m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_EXTRACT;
			}
			else
				bRetVal = FALSE;
		}
	}
	m_stRxMsgInfo.nCheckedLen = m_stRxMsgInfo.nRemainLen;

	return bRetVal;
}

BOOL COwnModBusSlave::ParseRequestMsgExtractData(void)
{
	BOOL bRetVal = TRUE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;

	if((nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_SINGLE_HOLD) ||
		(nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_MULTI_HOLD))
	{
		bRetVal = ExtractPresetDataFromRequestMsg();
	}
	else if((nRequestType == MODBUS_FUNC_READ_COIL) ||
		(nRequestType == MODBUS_FUNC_READ_STATE) ||
		(nRequestType == MODBUS_FUNC_READ_HOLD_REG) ||
		(nRequestType == MODBUS_FUNC_READ_INPUT_REG))
	{
		bRetVal = ExtractReadDataFromRequestMsg();
	}
	return bRetVal;
}

BOOL COwnModBusSlave::ExtractPresetDataFromRequestMsg(void)
{
	BOOL bRetVal = FALSE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;
	WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;
	char* pReplyMsg = m_stRxMsgInfo.bufRxMsg + m_stRxMsgInfo.nValue1stId;

	if((nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL) || 
		(nRequestType == MODBUS_FUNC_PRESET_SINGLE_HOLD))
	{
		WORD nRegAddr, nRegVal;

		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegAddr);
		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegVal);

		m_stRequestInfo.nWriteAddr = nRegAddr;
		m_stRequestInfo.nWriteCount = nRegVal;

		if(nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL)
		{
			if((nRegVal == 0xFF00) || (nRegVal == 0x0000))
			{
				if(m_lparrayCoils != NULL)
				{
					INT_PTR nRegCount = m_lparrayCoils->GetCount();
					for(INT_PTR nRegId = 0; nRegId < nRegCount; nRegId ++)
					{
						MODBUS_REGIST_INFO_ST& stRegistInfo = m_lparrayCoils->ElementAt(nRegId);
						if(stRegistInfo.nAddress == nRegAddr)
						{
							if(nRegVal == 0xFF00)
								stRegistInfo.nMsgValue = (DWORD)(TRUE);
							else
								stRegistInfo.nMsgValue = (DWORD)(FALSE);
							bRetVal = TRUE;
							break;
						}
					}
				}
				if(bRetVal == FALSE)
				{	//	No Existing Register
					m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
				}
			}
			else
			{	//	Value is No Effect
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_VALUE;
			}
		}
		else
		{
			if(m_lparrayHolds != NULL)
			{
				INT_PTR nRegCount = m_lparrayHolds->GetCount();
				for(INT_PTR nRegId = 0; nRegId < nRegCount; nRegId ++)
				{
					MODBUS_REGIST_INFO_ST& stRegistInfo = m_lparrayHolds->ElementAt(nRegId);
					if(stRegistInfo.nAddress == nRegAddr)
					{
						stRegistInfo.nMsgValue = (DWORD)(nRegVal);
						bRetVal = TRUE;
						break;
					}
				}
			}

			if(bRetVal == FALSE)
			{	//	No Existing Register
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
			}
		}
	}
	else if((nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_MULTI_HOLD))
	{
		WORD nRegAddr, nRegCount;

		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegAddr);
		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegCount);

		m_stRequestInfo.nWriteAddr = nRegAddr;
		m_stRequestInfo.nWriteCount = nRegCount;
		m_stRxMsgInfo.nValue1stId += 5;
		m_stRxMsgInfo.nValueCount -= 5;

		char* lpGetDataByte = &m_stRxMsgInfo.bufRxMsg[m_stRxMsgInfo.nValue1stId];

		if(nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL)
		{
			if(m_lparrayCoils == NULL)
			{
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
			} 
			else if(m_stRxMsgInfo.nValueCount != (((nRegCount & 0xFF80) >> 3) + (((nRegCount & 0x0007) == 0) ? 0 : 1)))
			{
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_VALUE;
			}
			else
			{
				for(WORD nRegSetCnt = 0 ; nRegSetCnt < nRegCount; nRegSetCnt ++)
				{
					MODBUS_REGIST_INFO_ST* lpRegisterInfo = (MODBUS_REGIST_INFO_ST*)
						GetRegisterInfoPointerFromRegAddr(m_lparrayCoils, nRegAddr);

					if(lpRegisterInfo != NULL)
					{
						if(lpGetDataByte[(nRegSetCnt & 0xFFF8) >> 3] & (1 << (nRegSetCnt & 0x0007)))
							lpRegisterInfo->nMsgValue = (DWORD)(TRUE);
						else
							lpRegisterInfo->nMsgValue = (DWORD)(FALSE);
					}
					else
						m_arrayForceErrAddr.Add(nRegAddr);

					nRegAddr ++;
				}

				if(m_arrayForceErrAddr.GetCount() == 0)
					bRetVal = TRUE;
				else
					m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
			}
		}
		else
		{
			if(m_lparrayHolds == NULL)
			{
				//	No Existing Register
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
			}
			else if(m_stRxMsgInfo.nValueCount != (m_stRequestInfo.nWriteCount >> 1))
			{
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_VALUE;
			}
			else
			{
				while(nRegCount > 0)
				{
					MODBUS_REGIST_INFO_ST* lpRegisterInfo = (MODBUS_REGIST_INFO_ST*)
						GetRegisterInfoPointerFromRegAddr(m_lparrayCoils, nRegAddr);

					if(lpRegisterInfo != NULL)
					{
						if(lpRegisterInfo->nMsgType > MODBUS_MSG_UINT)
						{
							DWORD nRegVal;
							MODBUS_DWORD_FROM_MSG(pReplyMsg, nRegVal);
							lpRegisterInfo->nMsgValue = nRegVal;
							nRegCount -= 2;
							nRegAddr += 2;
						}
						else
						{
							WORD nRegVal;
							MODBUS_WORD_FROM_MSG(pReplyMsg, nRegVal);
							lpRegisterInfo->nMsgValue = (DWORD)nRegVal;
							nRegCount --;
							nRegAddr ++;
						}
					}
					else
					{
						m_arrayForceErrAddr.Add(nRegAddr);
						nRegCount --;
						nRegAddr ++;
					}
				}

				if(m_arrayForceErrAddr.GetCount() == 0)
					bRetVal = TRUE;
				else
					m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
			}
		}
	}
	return bRetVal;
}

BOOL COwnModBusSlave::ExtractReadDataFromRequestMsg(void)
{
	BOOL bRetVal = FALSE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;
	WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;

	CModBusRegInfoArray* lpRegistInfoArray;

	char* pReplyMsg = m_stRxMsgInfo.bufRxMsg + m_stRxMsgInfo.nValue1stId;

	switch(nRequestType)
	{
	case MODBUS_FUNC_READ_COIL:
		lpRegistInfoArray = m_lparrayCoils;
		break;
	case MODBUS_FUNC_READ_STATE:
		lpRegistInfoArray = m_lparrayDiscrets;
		break;
	case MODBUS_FUNC_READ_HOLD_REG:
		lpRegistInfoArray = m_lparrayHolds;
		break;
	case MODBUS_FUNC_READ_INPUT_REG:
		lpRegistInfoArray = m_lparrayInputs;
		break;
	default:
		lpRegistInfoArray = NULL;
		break;
	}

	if(lpRegistInfoArray != NULL)
	{
		WORD nRegAddr, nRegCount;

		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegAddr);
		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegCount);

		m_stRequestInfo.nReadAddr = nRegAddr;
		m_stRequestInfo.nReadCount = nRegCount;

		if((nRequestType == MODBUS_FUNC_READ_COIL) ||
			(nRequestType == MODBUS_FUNC_READ_STATE))
		{
			while(nRegCount > 0)
			{
				MODBUS_REGIST_INFO_ST* lpRegisterInfo = (MODBUS_REGIST_INFO_ST*)
					GetRegisterInfoPointerFromRegAddr(lpRegistInfoArray, nRegAddr);

				if(lpRegisterInfo == NULL)
					m_arrayReadErrAddr.Add(nRegAddr);

				nRegCount --;
				nRegAddr ++;
			}

			if(m_arrayReadErrAddr.GetCount() == 0)
				bRetVal = TRUE;
			else
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
		}
		else
		{
			WORD nRegValLen;
			while(nRegCount > 0)
			{
				MODBUS_REGIST_INFO_ST* lpRegisterInfo = (MODBUS_REGIST_INFO_ST*)
					GetRegisterInfoPointerFromRegAddr(lpRegistInfoArray, nRegAddr);

				if(nRegCount == 0)
					break;

				if(lpRegisterInfo == NULL)
				{
					m_arrayReadErrAddr.Add(nRegAddr);
					nRegCount --;
					nRegAddr ++;
				}
				else
				{
					nRegValLen = (lpRegisterInfo->nMsgType < MODBUS_MSG_REAL) ? 1 : 2;
					if(lpRegisterInfo->nAddress != nRegAddr)
						nRegValLen -= (nRegAddr - lpRegisterInfo->nAddress);

					if(nRegCount < nRegValLen)
						nRegValLen = nRegCount;

					nRegAddr += nRegValLen;
					nRegCount -= nRegValLen;
				}
			}
			if(m_arrayReadErrAddr.GetCount() == 0)
				bRetVal = TRUE;
			else
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
		}
	}
	else
	{
		m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_ADDR;
	}
	return bRetVal;
}

WORD COwnModBusSlave::ConstructReplyMessage(char* lpDstMsg, WORD nBufLen)
{
//	if(m_stRequestInfo.enumErrState != MODBUS_ILLEGAL_NONE)
	if(m_stRequestInfo.enumErrState == MODBUS_ILLEGAL_FUNC)
	{
		return 0;
	}
	m_stTxMsgInfo.bufTxMsg = lpDstMsg;
	m_stTxMsgInfo.nBufLen = nBufLen;
	m_stTxMsgInfo.nMsgLen = 0;

	WORD& nRetVal = m_stTxMsgInfo.nMsgLen;

	ConstructTransMessageCommonHeader();

	ConstructReplyMsgBody();

	ConstructTransMessageComplete();

	return nRetVal;
}

WORD COwnModBusSlave::ConstructReplyMsgBody(void)
{
	BYTE nFuncCode = m_stRequestInfo.nFuncCode;
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;

	m_stTxMsgInfo.bufTxMsg[nMsgLen] = nFuncCode;
	nMsgLen ++;

	if(m_stRequestInfo.enumErrState != MODBUS_ILLEGAL_NONE)
	{
		ConstructReplyMsgErrorState();
	}
	else
	{
		if((nFuncCode == MODBUS_FUNC_FORCE_SINGLE_COIL) || 
			(nFuncCode == MODBUS_FUNC_PRESET_SINGLE_HOLD) || 
			(nFuncCode == MODBUS_FUNC_FORCE_MULTI_COIL) || 
			(nFuncCode == MODBUS_FUNC_PRESET_MULTI_HOLD))
		{
			ConstructReplyMsgWriteRegister();
		}
		else if((nFuncCode == MODBUS_FUNC_READ_COIL) || 
			(nFuncCode == MODBUS_FUNC_READ_STATE) || 
			(nFuncCode == MODBUS_FUNC_READ_HOLD_REG) || 
			(nFuncCode == MODBUS_FUNC_READ_INPUT_REG))
		{
			ConstructReplyMsgReadRegister();
		}
		else
			nMsgLen = 0;
	}

	return nMsgLen;
}

WORD COwnModBusSlave::ConstructReplyMsgErrorState(void)
{
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;
	char* lpszTxSetBuf = m_stTxMsgInfo.bufTxMsg + nMsgLen;
	*lpszTxSetBuf++ = (m_stRequestInfo.nFuncCode | 0x80);
	*lpszTxSetBuf = (char)(m_stRequestInfo.enumErrState);
	nMsgLen += 2;
	return nMsgLen;
}

WORD COwnModBusSlave::ConstructReplyMsgWriteRegister(void)
{
//	BYTE nFuncCode = m_stRequestInfo.nFuncCode;
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;

	char* lpszTxSetBuf = m_stTxMsgInfo.bufTxMsg + nMsgLen;

	MODBUS_WORD_TO_MSG(lpszTxSetBuf, m_stRequestInfo.nWriteAddr);
	MODBUS_WORD_TO_MSG(lpszTxSetBuf, m_stRequestInfo.nWriteCount);

	nMsgLen += 4;
	return nMsgLen;
}

WORD COwnModBusSlave::ConstructReplyMsgReadRegister(void)
{
	BYTE nFuncCode = m_stRequestInfo.nFuncCode;
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;

	char* lpszTxSetBuf = m_stTxMsgInfo.bufTxMsg + nMsgLen;
	CModBusRegInfoArray* lpRegistInfoArray;

	switch(nFuncCode)
	{
	case MODBUS_FUNC_READ_COIL:
		lpRegistInfoArray = m_lparrayCoils;
		break;
	case MODBUS_FUNC_READ_STATE:
		lpRegistInfoArray = m_lparrayDiscrets;
		break;
	case MODBUS_FUNC_READ_HOLD_REG:
		lpRegistInfoArray = m_lparrayHolds;
		break;
	case MODBUS_FUNC_READ_INPUT_REG:
		lpRegistInfoArray = m_lparrayInputs;
		break;
	}

	WORD nRegAddr = m_stRequestInfo.nReadAddr;
	WORD nRegCount = m_stRequestInfo.nReadCount;

	if((nFuncCode == MODBUS_FUNC_READ_COIL) || 
		(nFuncCode == MODBUS_FUNC_READ_STATE))
	{
		BYTE nByteCount = MODBUS_COIL_BYTE_LEN(nRegCount);

		*lpszTxSetBuf ++ = (nByteCount);
		nMsgLen ++;

		for(WORD nByteId =0; nByteId < nByteCount; nByteId ++)
			lpszTxSetBuf[nByteId] = 0x00;

		for(WORD nRegId = 0; nRegId < nRegCount; nRegId ++)
		{
			MODBUS_REGIST_INFO_ST* lpRegisterInfo = (MODBUS_REGIST_INFO_ST*)
				GetRegisterInfoPointerFromRegAddr(lpRegistInfoArray, nRegAddr);

			if(lpRegisterInfo == NULL)
			{
				m_arrayReadErrAddr.Add(nRegAddr);
			}
			else
			{
				if(lpRegisterInfo->nMsgValue == TRUE)
					lpszTxSetBuf[MODBUS_COIL_BYTE_POS(nRegId)] |= MODBUS_COIL_BIT_VAL(nRegId);
			}
			nRegAddr ++;
		}
		nMsgLen += nByteCount;
	}
	else
	{
		WORD nByteCount = nRegCount << 1;
		nByteCount &= 0xFF;
		*lpszTxSetBuf ++ = (BYTE)(nByteCount);
		nMsgLen ++;
		WORD nRegValLen;
		while(nRegCount > 0)
		{
			MODBUS_REGIST_INFO_ST* lpRegisterInfo = (MODBUS_REGIST_INFO_ST*)
				GetRegisterInfoPointerFromRegAddr(lpRegistInfoArray, nRegAddr);

			if(lpRegisterInfo == NULL)
			{
				m_arrayReadErrAddr.Add(nRegAddr);
				*(short*)lpszTxSetBuf = 0x0000;
				nRegCount --;
				nRegAddr ++;
			}
			else
			{
				if(lpRegisterInfo->nAddress != nRegAddr)
				{
					WORD nRegPartVal = (WORD)((lpRegisterInfo->nMsgValue >> 16) & 0xFFFF);
					MODBUS_WORD_TO_MSG(lpszTxSetBuf, nRegPartVal);
					nRegCount --;
					nRegAddr ++;
				}
				else
				{
					nRegValLen = (lpRegisterInfo->nMsgType < MODBUS_MSG_REAL) ? 1 : 2;
					if((nRegValLen <= nRegCount) && (nRegValLen > 1))
					{
						MODBUS_DWORD_TO_MSG(lpszTxSetBuf, lpRegisterInfo->nMsgValue);
						nRegCount -= 2;
						nRegAddr += 2;
					}
					else
					{
						MODBUS_WORD_TO_MSG(lpszTxSetBuf, (WORD)lpRegisterInfo->nMsgValue);
						nRegCount --;
						nRegAddr ++;
					}
				}
			}
		}
		nMsgLen += nByteCount;
	}

	return nMsgLen;
}

COwnModBusSlave& COwnModBusSlave::operator=(COwnModBusSlave& clsSrcSlave)
{
	//TODO: insert return statement here
	COwnModBusDef* lpOwnThis = (COwnModBusDef*)this;
	*lpOwnThis = *((COwnModBusDef*)&clsSrcSlave);

	return *this;
}
