#include "StdAfx.h"
#include "OwnModBusMaster.h"

COwnModBusMaster::COwnModBusMaster(void)
: m_boolDeviceLinkFlag(FALSE)
{
	m_intModBusMasterType = MODBUS_CLASS_TYPE_MASTER;

	m_lparrayCoilReadType = NULL;
	m_lparrayCoilForceType = NULL;

	m_lparrayDiscretReadType = NULL;

	m_lparrayHoldReadType = NULL;
	m_lparrayHoldWriteType = NULL;

	m_lparrayInputReadType = NULL;

	m_stModBusAccessReadState.enumRegSortType = MODBUS_REG_COIL;
	m_stModBusAccessReadState.nAccessId = 0;

	m_stModBusAccessWriteState.enumRegSortType = MODBUS_REG_COIL;
	m_stModBusAccessWriteState.nAccessId = 0;

	InitRxStateStruct();
}

COwnModBusMaster::~COwnModBusMaster(void)
{
	//	Remove Coil Access Type
	if(m_lparrayCoilReadType)
	{
		m_lparrayCoilReadType->RemoveAll();
		delete m_lparrayCoilReadType;
	}
	if(m_lparrayCoilForceType)
	{
		m_lparrayCoilForceType->RemoveAll();
		delete m_lparrayCoilForceType;
	}

	//	Remove Discret Access Type
	if(m_lparrayDiscretReadType)
	{
		m_lparrayDiscretReadType->RemoveAll();
		delete m_lparrayDiscretReadType;
	}

	//	Remove Hold Access Type
	if(m_lparrayHoldReadType)
	{
		m_lparrayHoldReadType->RemoveAll();
		delete m_lparrayHoldReadType;
	}
	if(m_lparrayHoldWriteType)
	{
		m_lparrayHoldWriteType->RemoveAll();
		delete m_lparrayHoldWriteType;
	}

	//	Remove Input Access Type
	if(m_lparrayInputReadType)
	{
		m_lparrayInputReadType->RemoveAll();
		delete m_lparrayInputReadType;
	}

}

/*=============================================================*
 *
 *
 *
 *=============================================================*/

MODBUS_REGIST_ACCESS_ST* COwnModBusMaster::GetAccessRegistPointerFromArray(
	CModBusAccessTypeArray* lpRegAccessInfoArray, WORD nAccessId)
{
	CModBusAccessTypeArray* lpAccessInfoArray = 
		(CModBusAccessTypeArray*)lpRegAccessInfoArray;

	if(lpAccessInfoArray == NULL)
		return NULL;

	WORD nRequestCount = (WORD)lpAccessInfoArray->GetCount();
	if(nRequestCount <= nAccessId)
		return NULL;

	return &(lpAccessInfoArray->ElementAt(nAccessId));
}

CModBusAccessTypeArray* COwnModBusMaster::GetModBusAccessReadArrayByType(
	MODBUS_REG_TYPE_SORT enumRegType, BOOL bCreate)
{
	CModBusAccessTypeArray* lpAccessReadArray = NULL;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:	//	Coil : 0
		lpAccessReadArray = m_lparrayCoilReadType;
		if((lpAccessReadArray == NULL) && (bCreate))
		{
			lpAccessReadArray = new CModBusAccessTypeArray;
			m_lparrayCoilReadType = lpAccessReadArray;
		}
		break;
	case MODBUS_REG_DISCRET:		//	Discrete State : 1
		lpAccessReadArray = m_lparrayDiscretReadType;
		if((lpAccessReadArray == NULL) && (bCreate))
		{
			lpAccessReadArray = new CModBusAccessTypeArray;
			m_lparrayDiscretReadType = lpAccessReadArray;
		}
		break;
	case MODBUS_REG_HOLD:	//	Hold Reigister : 2
		lpAccessReadArray = m_lparrayHoldReadType;
		if((lpAccessReadArray == NULL) && (bCreate))
		{
			lpAccessReadArray = new CModBusAccessTypeArray;
			m_lparrayHoldReadType = lpAccessReadArray;
		}
		break;
	case MODBUS_REG_INPUT:	//	Input Register : 3
		lpAccessReadArray = m_lparrayInputReadType;
		if((lpAccessReadArray == NULL) && (bCreate))
		{
			lpAccessReadArray = new CModBusAccessTypeArray;
			m_lparrayInputReadType = lpAccessReadArray;
		}
		break;
	default:
		break;
	}

	return lpAccessReadArray;
}

CModBusAccessTypeArray* COwnModBusMaster::GetModBusAccessWriteArrayByType(
	MODBUS_REG_TYPE_SORT enumRegType, BOOL bCreate)
{
	CModBusAccessTypeArray* lpAccessWriteArray = NULL;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:	//	Coil : 0
		lpAccessWriteArray = m_lparrayCoilForceType;
		if((lpAccessWriteArray == NULL) && (bCreate))
		{
			lpAccessWriteArray = new CModBusAccessTypeArray;
			m_lparrayCoilForceType = lpAccessWriteArray;
		}
		break;
	case MODBUS_REG_HOLD:	//	Hold Reigister : 2
		lpAccessWriteArray = m_lparrayHoldWriteType;
		if((lpAccessWriteArray == NULL) && (bCreate))
		{
			lpAccessWriteArray = new CModBusAccessTypeArray;
			m_lparrayHoldWriteType = lpAccessWriteArray;
		}
		break;
	default:
		break;
	}

	return lpAccessWriteArray;
}

WORD COwnModBusMaster::AppendModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType, WORD nAddr, WORD nCount)
{
	WORD nRetVal = 0xFFFF;
	CModBusAccessTypeArray* lpAccessReadArray = (CModBusAccessTypeArray*)
		GetModBusAccessReadArrayByType(enumRegType);

	if((lpAccessReadArray != NULL) && (lpAccessReadArray->GetCount() < MODBUS_REGISTER_COUNT))
	{
		MODBUS_REGIST_ACCESS_ST stRegAccessSpec;
		stRegAccessSpec.nAddress = nAddr;
		stRegAccessSpec.nCount = nCount;

		return (WORD)lpAccessReadArray->Add(stRegAccessSpec);
	}

	return nRetVal;
}

WORD COwnModBusMaster::InsertAtModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType, WORD nInsertPos, WORD nAddr, WORD nCount)
{
	WORD nRetVal = 0xFFFF;
	CModBusAccessTypeArray* lpAccessReadArray = (CModBusAccessTypeArray*)
		GetModBusAccessReadArrayByType(enumRegType);

	if((lpAccessReadArray != NULL) && (lpAccessReadArray->GetCount() < MODBUS_REGISTER_COUNT))
	{
		MODBUS_REGIST_ACCESS_ST stRegAccessSpec;
		stRegAccessSpec.nAddress = nAddr;
		stRegAccessSpec.nCount = nCount;
		if(nInsertPos < lpAccessReadArray->GetCount())
		{
			lpAccessReadArray->InsertAt(nInsertPos, stRegAccessSpec);
			return nInsertPos;
		}
		else
			return (WORD)lpAccessReadArray->Add(stRegAccessSpec);
	}

	return nRetVal;
}

void COwnModBusMaster::RemoveAtModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType, WORD nRemovePos)
{
	CModBusAccessTypeArray* lpAccessReadArray = (CModBusAccessTypeArray*)
		GetModBusAccessReadArrayByType(enumRegType, FALSE);

	if((lpAccessReadArray != NULL) && (lpAccessReadArray->GetCount() > nRemovePos))
	{
		lpAccessReadArray->RemoveAt(nRemovePos);
	}
}

void COwnModBusMaster::RemoveAllModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType)
{
	CModBusAccessTypeArray* lpAccessReadArray = (CModBusAccessTypeArray*)
		GetModBusAccessReadArrayByType(enumRegType, FALSE);

	if(lpAccessReadArray != NULL)
	{
		lpAccessReadArray->RemoveAll();
	}
}

WORD COwnModBusMaster::AppendModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType, WORD nAddr, WORD nCount)
{
	WORD nRetVal = 0xFFFF;
	CModBusAccessTypeArray* lpAccessWriteArray = (CModBusAccessTypeArray*)
		GetModBusAccessWriteArrayByType(enumRegType);

	if((lpAccessWriteArray != NULL) && (lpAccessWriteArray->GetCount() < MODBUS_REGISTER_COUNT))
	{
		MODBUS_REGIST_ACCESS_ST stRegAccessSpec;
		stRegAccessSpec.nAddress = nAddr;
		stRegAccessSpec.nCount = nCount;

		return (WORD)lpAccessWriteArray->Add(stRegAccessSpec);
	}

	return nRetVal;
}

WORD COwnModBusMaster::InsertAtModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType, WORD nInsertPos, WORD nAddr, WORD nCount)
{
	WORD nRetVal = 0xFFFF;
	CModBusAccessTypeArray* lpAccessWriteArray = (CModBusAccessTypeArray*)
		GetModBusAccessWriteArrayByType(enumRegType);

	if((lpAccessWriteArray != NULL) && (lpAccessWriteArray->GetCount() < MODBUS_REGISTER_COUNT))
	{
		MODBUS_REGIST_ACCESS_ST stRegAccessSpec;
		stRegAccessSpec.nAddress = nAddr;
		stRegAccessSpec.nCount = nCount;
		if(nInsertPos < lpAccessWriteArray->GetCount())
		{
			lpAccessWriteArray->InsertAt(nInsertPos, stRegAccessSpec);
			return nInsertPos;
		}
		else
			return (WORD)lpAccessWriteArray->Add(stRegAccessSpec);
	}
	return nRetVal;
}

void COwnModBusMaster::RemoveAtModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType, WORD nRemovePos)
{
	CModBusAccessTypeArray* lpAccessWriteArray = (CModBusAccessTypeArray*)
		GetModBusAccessReadArrayByType(enumRegType, FALSE);

	if((lpAccessWriteArray != NULL) && (lpAccessWriteArray->GetCount() > nRemovePos))
	{
		lpAccessWriteArray->RemoveAt(nRemovePos);
	}
}

void COwnModBusMaster::RemoveAllModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType)
{
	CModBusAccessTypeArray* lpAccessWriteArray = (CModBusAccessTypeArray*)
		GetModBusAccessWriteArrayByType(enumRegType, FALSE);

	if(lpAccessWriteArray != NULL)
	{
		lpAccessWriteArray->RemoveAll();
	}
}

/*=================================================================*
 *
 *
 *=================================================================*/

WORD COwnModBusMaster::ConstructRequestMessageReadIndirect(
	MODBUS_REG_TYPE_SORT enumRegType, 
	WORD nAccessId, char* lpDstMsg, WORD nBufLen)
{
	CModBusAccessTypeArray* lparrayReadConfType;

	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		lparrayReadConfType = m_lparrayCoilReadType;
		break;
	case MODBUS_REG_DISCRET:
		lparrayReadConfType = m_lparrayDiscretReadType;
		break;
	case MODBUS_REG_HOLD:
		lparrayReadConfType = m_lparrayHoldReadType;
		break;
	case MODBUS_REG_INPUT:
		lparrayReadConfType = m_lparrayInputReadType;
		break;
	}

	MODBUS_REGIST_ACCESS_ST* lpstRequestInfo = (MODBUS_REGIST_ACCESS_ST*)
		GetAccessRegistPointerFromArray(lparrayReadConfType, nAccessId);

	if(lpstRequestInfo == NULL)
		return 0;

	WORD nMsgLen = ConstructRequestMessageReadDirect(enumRegType, 
		lpstRequestInfo->nAddress, lpstRequestInfo->nCount, 
		lpDstMsg, nBufLen);

	return nMsgLen;
}

WORD COwnModBusMaster::ConstructRequestMessageReadDirect(
	MODBUS_REG_TYPE_SORT enumRegType, 
	WORD nAddress, WORD nCount, char* lpDstMsg, WORD nBufLen)
{
	BYTE nFuncCode;

	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		nFuncCode = MODBUS_FUNC_READ_COIL;
		break;
	case MODBUS_REG_DISCRET:
		nFuncCode = MODBUS_FUNC_READ_STATE;
		break;
	case MODBUS_REG_HOLD:
		nFuncCode = MODBUS_FUNC_READ_HOLD_REG;
		break;
	case MODBUS_REG_INPUT:
		nFuncCode = MODBUS_FUNC_READ_INPUT_REG;
		break;
	}

	m_stRequestInfo.nFuncCode = nFuncCode;
	m_stRequestInfo.nReadAddr = nAddress;
	m_stRequestInfo.nReadCount = nCount;

	m_stTxMsgInfo.bufTxMsg = lpDstMsg;
	m_stTxMsgInfo.nBufLen = nBufLen;
	m_stTxMsgInfo.nMsgLen = 0;

	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;
	char *lpMsgBody = lpDstMsg;

	ConstructTransMessageCommonHeader();
	lpMsgBody += nMsgLen;

	*lpMsgBody ++ = nFuncCode;
	nMsgLen ++;

	MODBUS_WORD_TO_MSG(lpMsgBody, nAddress);
	MODBUS_WORD_TO_MSG(lpMsgBody, nCount);

	nMsgLen += 4;

	ConstructTransMessageComplete();

	return nMsgLen;
}

WORD COwnModBusMaster::ConstructRequestMessageWriteIndirect(
	MODBUS_REG_TYPE_SORT enumRegType, 
	WORD nAccessId, char* lpDstMsg, WORD nBufLen)
{
	CModBusAccessTypeArray* lparrayWriteConfType = NULL;

	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		lparrayWriteConfType = m_lparrayCoilForceType;
		break;
	case MODBUS_REG_HOLD:
		lparrayWriteConfType = m_lparrayHoldWriteType;
		break;
	default:
		break;
	}

	if(lparrayWriteConfType == NULL)
		return 0;

	MODBUS_REGIST_ACCESS_ST* lpstRequestInfo = (MODBUS_REGIST_ACCESS_ST*)
		GetAccessRegistPointerFromArray(lparrayWriteConfType, nAccessId);

	if(lpstRequestInfo == NULL)
		return 0;

	WORD nMsgLen = ConstructRequestMessageWriteDirect(enumRegType, 
		lpstRequestInfo->nAddress, lpstRequestInfo->nCount, 
		lpDstMsg, nBufLen);

	return nMsgLen;
}

WORD COwnModBusMaster::ConstructRequestMessageWriteDirect(
	MODBUS_REG_TYPE_SORT enumRegType, 
	WORD nAddress, WORD nCount, char* lpDstMsg, WORD nBufLen)
{
	BYTE nFuncCode;
	BOOL bRegTypeFail = FALSE;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		nFuncCode = MODBUS_FUNC_FORCE_MULTI_COIL;
		break;
	case MODBUS_REG_HOLD:
		nFuncCode = MODBUS_FUNC_PRESET_MULTI_HOLD;
		break;
	default:
		bRegTypeFail = TRUE;
		break;
	}

	if(bRegTypeFail)
		return 0;

	m_stRequestInfo.nFuncCode = nFuncCode;
	m_stRequestInfo.nWriteAddr = nAddress;
	m_stRequestInfo.nWriteCount = nCount;

	m_stTxMsgInfo.bufTxMsg = lpDstMsg;
	m_stTxMsgInfo.nBufLen = nBufLen;
	m_stTxMsgInfo.nMsgLen = 0;

	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;

	ConstructTransMessageCommonHeader();
	char *lpMsgBody = lpDstMsg + nMsgLen;

	MODBUS_WORD_TO_MSG(lpMsgBody, nAddress);
	MODBUS_WORD_TO_MSG(lpMsgBody, nCount);

	nMsgLen += 4;

	if(m_stRequestInfo.nFuncCode == MODBUS_FUNC_FORCE_MULTI_COIL)
	{
		if((m_lparrayCoils == NULL) || (m_lparrayCoils->GetCount() == 0))
		{
			nMsgLen = 0;
			return nMsgLen;
		}

		WORD nStartAddr = nAddress;
		BYTE nDataByteLen = MODBUS_COIL_BYTE_LEN(nCount);

		*lpMsgBody ++ = nDataByteLen;
		nMsgLen ++;
		for(BYTE nByteId = 0; nByteId < nDataByteLen; nByteId ++)
			lpMsgBody[nByteId] = 0x00;

		for(WORD nRegCnt = 0; nRegCnt < nCount; nRegCnt ++)
		{
			MODBUS_REGIST_INFO_ST* lpCoilRegInfo = (MODBUS_REGIST_INFO_ST*)
				GetRegisterInfoPointerFromRegAddr(m_lparrayCoils, nStartAddr);

			if(lpCoilRegInfo != NULL)
			{
				if((BOOL)lpCoilRegInfo->nMsgValue == TRUE)
				{
					lpMsgBody[MODBUS_COIL_BYTE_POS(nRegCnt)] |= 
						MODBUS_COIL_BIT_VAL(nRegCnt);
				}
			}
			nStartAddr ++;
		}
		nMsgLen += (WORD)nDataByteLen;
	}
	else
	{
		if((m_lparrayHolds == NULL) || (m_lparrayHolds->GetCount() == 0))
		{
			nMsgLen = 0;
			return nMsgLen;
		}
		WORD nStartAddr = nAddress;
		BYTE nDataByteLen = (BYTE)(nCount << 1);

		*lpMsgBody ++ = nDataByteLen;
		nMsgLen ++;

		for(WORD nRegCnt = 0; nRegCnt < nCount; nRegCnt ++)
		{
			MODBUS_REGIST_INFO_ST* lpHoldRegInfo = (MODBUS_REGIST_INFO_ST*)
				GetRegisterInfoPointerFromRegAddr(m_lparrayHolds, nStartAddr);

			if(lpHoldRegInfo != NULL)
			{
				if(lpHoldRegInfo->nMsgType > MODBUS_MSG_UINT)
				{
					MODBUS_DWORD_TO_MSG(lpMsgBody, lpHoldRegInfo->nMsgValue);
					nStartAddr += 2;
					nRegCnt ++;
				}
				else
				{
					MODBUS_WORD_TO_MSG(lpMsgBody, (WORD)lpHoldRegInfo->nMsgValue);
					nStartAddr ++;
				}
			}
			else
			{
				MODBUS_WORD_TO_MSG(lpMsgBody, (WORD)0);
				nStartAddr ++;
			}
		}
		nMsgLen += nDataByteLen;
	}

	ConstructTransMessageComplete();

	return nMsgLen;
}

WORD COwnModBusMaster::ConstructRequestMessageWriteSingle(MODBUS_REG_TYPE_SORT enumRegType, WORD nAddress, char* lpDstMsg, WORD nBufLen)
{
	BYTE nFuncCode;
	BOOL bRegTypeFail = FALSE;
	switch(enumRegType)
	{
	case MODBUS_REG_COIL:
		nFuncCode = MODBUS_FUNC_FORCE_SINGLE_COIL;
		break;
	case MODBUS_REG_HOLD:
		nFuncCode = MODBUS_FUNC_PRESET_SINGLE_HOLD;
		break;
	default:
		bRegTypeFail = TRUE;
		break;
	}

	if(bRegTypeFail)
		return 0;

	m_stRequestInfo.nFuncCode = nFuncCode;
	m_stRequestInfo.nWriteAddr = nAddress;
	WORD nValue;

	m_stTxMsgInfo.bufTxMsg = lpDstMsg;
	m_stTxMsgInfo.nBufLen = nBufLen;
	m_stTxMsgInfo.nMsgLen = 0;
	WORD& nMsgLen = m_stTxMsgInfo.nMsgLen;

	if(enumRegType == MODBUS_REG_COIL)
	{
		MODBUS_REGIST_INFO_ST* lpCoilRegInfo = (MODBUS_REGIST_INFO_ST*)
			GetRegisterInfoPointerFromRegAddr(m_lparrayCoils, nAddress);

		if(lpCoilRegInfo)
		{
			nValue = (WORD)lpCoilRegInfo->nMsgValue;
		}
		else
		{
			nMsgLen = 0;
			return 0;
		}
	}
	else
	{
		MODBUS_REGIST_INFO_ST* lpHoldRegInfo = (MODBUS_REGIST_INFO_ST*)
			GetRegisterInfoPointerFromRegAddr(m_lparrayHolds, nAddress);
		if(lpHoldRegInfo)
		{
			nValue = (WORD)lpHoldRegInfo->nMsgValue;
		}
		else
		{
			nMsgLen = 0;
			return 0;
		}
	}

	m_stRequestInfo.nWriteCount = nValue;


	ConstructTransMessageCommonHeader();
	char *lpMsgBody = lpDstMsg + nMsgLen;

	MODBUS_WORD_TO_MSG(lpMsgBody, nAddress);
	MODBUS_WORD_TO_MSG(lpMsgBody, nValue);

	nMsgLen += 4;

	ConstructTransMessageComplete();

	return nMsgLen;
}

/*==================================================================*
 *
 *
 *
 *==================================================================*/
BOOL COwnModBusMaster::ParseReplyMessage(char* lpReplyMsg, WORD nRxLen)
{
	char* lpRxCombBuf	= m_stRxMsgInfo.bufRxMsg;
	WORD& nRemainLen	= m_stRxMsgInfo.nRemainLen;
	WORD& nCheckedLen	= m_stRxMsgInfo.nCheckedLen;
	MODBUS_RECV_MSG_PROC_STAGE& enumProcStage = m_stRxMsgInfo.enumProcStage;

	memcpy(lpRxCombBuf + nRemainLen, lpReplyMsg, nRxLen);
	nRemainLen += nRxLen;

	BOOL bMsgCorrect = TRUE;
	BOOL bNextParse = (nRemainLen > nCheckedLen) ? TRUE : FALSE;
	while(bNextParse && bMsgCorrect)
	{
		switch(enumProcStage)
		{
		case MODBUS_RECV_MSG_HEADER:
			m_arrayForceErrAddr.RemoveAll();
			m_arrayReadErrAddr.RemoveAll();
			m_stRxMsgInfo.bBusyFlag = TRUE;
			m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_NONE;
			bMsgCorrect = ParseRecvMessageCommonHeader();
			break;
		case MODBUS_RECV_MSG_COMMAND:
			bMsgCorrect = ParseReplyMsgCheckCommandType();
			break;
		case MODBUS_RECV_MSG_PARSING:
			bMsgCorrect = ParseReplyMsgParsingFunction();
			break;
		case MODBUS_RECV_MSG_RECVEND:
			bMsgCorrect = ParseReplyMsgWaitEndChar();
			if(enumProcStage == MODBUS_RECV_MSG_EXTRACT)
				bNextParse = TRUE;
			break;
		case MODBUS_RECV_MSG_EXTRACT:
			bMsgCorrect = ParseReplyMsgExtractData();
			InitRxStateStruct();
			bNextParse = FALSE;
			break;
		default:
			break;
		}

		if((bMsgCorrect == TRUE) && (bNextParse == TRUE) && 
			(enumProcStage != MODBUS_RECV_MSG_EXTRACT))
		{
			bNextParse = (nRemainLen > nCheckedLen) ? TRUE : FALSE;
		}
	}

	if(bMsgCorrect == FALSE)
	{
		InitRxStateStruct();
	}
	return bMsgCorrect;
}

BOOL COwnModBusMaster::ParseReplyMsgCheckCommandType(void)
{
	BOOL bRetVal = TRUE;
	WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;
	if(m_stRxMsgInfo.nRemainLen >= nCheckedLen + 1)
	{
		char *lpCommandBuf = m_stRxMsgInfo.bufRxMsg;
		lpCommandBuf += nCheckedLen;
		BYTE nRequestType = *(BYTE*)lpCommandBuf;
		if(nRequestType == m_stRequestInfo.nFuncCode)
		{
			nCheckedLen ++;
			m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_PARSING;
		}
		else if(nRequestType == (m_stRequestInfo.nFuncCode | 0x80))
		{
			m_stRequestInfo.nFuncCode = nRequestType;
			nCheckedLen ++;
			m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_PARSING;
		}
		else
		{
			bRetVal = FALSE;
		}
	}
	return bRetVal;
}

BOOL COwnModBusMaster::ParseReplyMsgParsingFunction(void)
{
	BOOL bRetVal = TRUE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;

	if((nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_SINGLE_HOLD) ||
		(nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_MULTI_HOLD))
	{
		m_stRxMsgInfo.nValue1stId = m_stRxMsgInfo.nCheckedLen;
		m_stRxMsgInfo.nValueCount = 4;
		m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_RECVEND;
	}
	else if((nRequestType == MODBUS_FUNC_READ_COIL) ||
		(nRequestType == MODBUS_FUNC_READ_STATE) ||
		(nRequestType == MODBUS_FUNC_READ_HOLD_REG) ||
		(nRequestType == MODBUS_FUNC_READ_INPUT_REG))
	{
		WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;
		char* lpMsgBuf = m_stRxMsgInfo.bufRxMsg;

		if(m_stRxMsgInfo.nRemainLen >= nCheckedLen + 1)
		{
			lpMsgBuf += nCheckedLen;
			m_stRxMsgInfo.nValueCount = ((WORD)(*lpMsgBuf) & 0x00FF);
			nCheckedLen ++;
			m_stRxMsgInfo.nValue1stId = nCheckedLen;
			m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_RECVEND;
		}
	}
	else if(nRequestType & 0x80)
	{
		m_stRxMsgInfo.nValue1stId = m_stRxMsgInfo.nCheckedLen;
		m_stRxMsgInfo.nValueCount = 1;
	}
	else
	{
		bRetVal = FALSE;
	}
	return bRetVal;
}

BOOL COwnModBusMaster::ParseReplyMsgWaitEndChar(void)
{
	BOOL bRetVal = TRUE;
	WORD nTotalLen = m_stRxMsgInfo.nValue1stId + m_stRxMsgInfo.nValueCount;
	if(m_boolEthernetType == TRUE)
	{
		if(m_stRxMsgInfo.nRemainLen >= nTotalLen)
			m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_EXTRACT;
	}
	else
	{
		if(m_stRxMsgInfo.nRemainLen >= nTotalLen + 2)
		{
			char* lpMsgBuf = m_stRxMsgInfo.bufRxMsg;
			WORD nCRCVal = GetModBusCRCSumValue(lpMsgBuf, nTotalLen);
			lpMsgBuf += nTotalLen;
			WORD nCRCGet = *(WORD*)lpMsgBuf;
			if(nCRCVal != nCRCGet)
			{
				bRetVal = FALSE;
				m_stRequestInfo.enumErrState = MODBUS_ILLEGAL_CHECK;
			}
			else
				m_stRxMsgInfo.enumProcStage = MODBUS_RECV_MSG_EXTRACT;
		}
	}
	m_stRxMsgInfo.nCheckedLen = m_stRxMsgInfo.nRemainLen;

	return bRetVal;
}

BOOL COwnModBusMaster::ParseReplyMsgExtractData(void)
{
	BOOL bRetVal = TRUE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;

	if((nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_SINGLE_HOLD) ||
		(nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_MULTI_HOLD))
	{
		bRetVal = ExtractPresetDataFromReplyMsg();
	}
	else if((nRequestType == MODBUS_FUNC_READ_COIL) ||
		(nRequestType == MODBUS_FUNC_READ_STATE) ||
		(nRequestType == MODBUS_FUNC_READ_HOLD_REG) ||
		(nRequestType == MODBUS_FUNC_READ_INPUT_REG))
	{
		bRetVal = ExtractReadDataFromReplyMsg();
	}
	else if(nRequestType & 0x80)
	{
		bRetVal = ExtractErrorCodeFromReplyMsg();
	}
	return bRetVal;
}

BOOL COwnModBusMaster::ExtractPresetDataFromReplyMsg(void)
{
	BOOL bRetVal = TRUE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;
	WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;
	char* pReplyMsg = m_stRxMsgInfo.bufRxMsg + m_stRxMsgInfo.nValue1stId;

	if((nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL) || 
		(nRequestType == MODBUS_FUNC_PRESET_SINGLE_HOLD))
	{
		WORD nRegAddr, nRegVal;

		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegAddr);
		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegVal);

		if(nRequestType == MODBUS_FUNC_FORCE_SINGLE_COIL)
		{
			CModBusRegInfoArray* lpRegArray = m_lparrayCoils;

			MODBUS_REGIST_INFO_ST* lpstRegistInfo = (MODBUS_REGIST_INFO_ST*)
				GetRegisterInfoPointerFromRegAddr(lpRegArray, m_stRequestInfo.nWriteAddr);

			if((lpstRegistInfo->nAddress != nRegAddr) || (lpstRegistInfo->nMsgValue != nRegVal))
				bRetVal = FALSE;
		}
		else
		{
			CModBusRegInfoArray* lpRegArray = m_lparrayHolds;

			MODBUS_REGIST_INFO_ST* lpstRegistInfo = (MODBUS_REGIST_INFO_ST*)
				GetRegisterInfoPointerFromRegAddr(lpRegArray, m_stRequestInfo.nWriteAddr);

			if((lpstRegistInfo->nAddress != nRegAddr) || (lpstRegistInfo->nMsgValue != nRegVal))
				bRetVal = FALSE;
		}
	}
	else if((nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL) ||
		(nRequestType == MODBUS_FUNC_PRESET_MULTI_HOLD))
	{
		WORD nRegAddr, nRegCount;

		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegAddr);
		MODBUS_WORD_FROM_MSG(pReplyMsg, nRegCount);

	//	if(nRequestType == MODBUS_FUNC_FORCE_MULTI_COIL)
		{
			if((nRegAddr != m_stRequestInfo.nWriteAddr) || 
				(nRegCount != m_stRequestInfo.nWriteCount))
				bRetVal = FALSE;
		}
	/*	else
		{
			if((nRegAddr != m_stRequestInfo.nWriteAddr) || 
				(nRegCount != m_stRequestInfo.nWriteCount))
				bRetVal = FALSE;
		}*/
	}
	return bRetVal;
}

BOOL COwnModBusMaster::ExtractReadDataFromReplyMsg(void)
{
	BOOL bRetVal = TRUE;
	BYTE nRequestType = m_stRequestInfo.nFuncCode;
	WORD& nCheckedLen = m_stRxMsgInfo.nCheckedLen;

	WORD nRegAddr, nRegCount;
	CModBusRegInfoArray*	lpRegisterArray;

	if((nRequestType == MODBUS_FUNC_READ_COIL) ||
		(nRequestType == MODBUS_FUNC_READ_STATE))
	{
		if(nRequestType == MODBUS_FUNC_READ_COIL)
		{
			nRegAddr = m_stRequestInfo.nReadAddr;
			nRegCount = m_stRequestInfo.nReadCount;
			lpRegisterArray = m_lparrayCoils;
		}
		else
		{
			nRegAddr = m_stRequestInfo.nReadAddr;
			nRegCount = m_stRequestInfo.nReadCount;
			lpRegisterArray = m_lparrayDiscrets;
		}

		WORD nValCount = m_stRxMsgInfo.nValueCount;
		char* lpRxMsgBuf = m_stRxMsgInfo.bufRxMsg + m_stRxMsgInfo.nValue1stId;
		char nGetStatePack;
		WORD nRemainCount;
		MODBUS_REGIST_INFO_ST* lpstRegisterInfo = NULL;
		WORD nByteSize = 8;	//	sizeof(BYTE) * 8;

		for(WORD nValId = 0; nValId < nValCount; nValId ++)
		{
			if(nRegCount > nByteSize)
			{
				nRemainCount = nByteSize;
				nRegCount -= nByteSize;
			}
			else
			{
				nRemainCount = nRegCount;
				nRegCount = 0;
			}

			nGetStatePack = *lpRxMsgBuf ++;

			for(WORD nBitId = 0; nBitId < nRemainCount; nBitId ++)
			{
				lpstRegisterInfo = (MODBUS_REGIST_INFO_ST*)
					GetRegisterInfoPointerFromRegAddr(lpRegisterArray, nRegAddr);
				
				if(lpstRegisterInfo != NULL)
				{
					if(nGetStatePack & (1 << nBitId))
					{
						lpstRegisterInfo->nMsgValue = 1;
					}
					else
					{
						lpstRegisterInfo->nMsgValue = 0;
					}
				}
				else
				{
					bRetVal = FALSE;
					nRegCount = 0;
					break;
				}
				nRegAddr ++;
			}

			if(nRegCount < 1)
				break;
		}
	}
	else if((nRequestType == MODBUS_FUNC_READ_HOLD_REG) ||
		(nRequestType == MODBUS_FUNC_READ_INPUT_REG))
	{
		if(nRequestType == MODBUS_FUNC_READ_HOLD_REG)
		{
			nRegAddr = m_stRequestInfo.nReadAddr;
			nRegCount = m_stRequestInfo.nReadCount;
			lpRegisterArray = m_lparrayHolds;
		}
		else
		{
			nRegAddr = m_stRequestInfo.nReadAddr;
			nRegCount = m_stRequestInfo.nReadCount;
			lpRegisterArray = m_lparrayInputs;
		}

		WORD nValCount = m_stRxMsgInfo.nValueCount;
		char* lpRxMsgBuf = m_stRxMsgInfo.bufRxMsg + m_stRxMsgInfo.nValue1stId;
		MODBUS_REGIST_INFO_ST* lpstRegisterInfo = NULL;

		nValCount >>= 1;
		if(nValCount == nRegCount)
		{
			while(nRegCount > 0)
			{
				lpstRegisterInfo = (MODBUS_REGIST_INFO_ST*)
					GetRegisterInfoPointerFromRegAddr(lpRegisterArray, nRegAddr);

				if(lpstRegisterInfo != NULL)
				{
					if(lpstRegisterInfo->nMsgType < MODBUS_MSG_REAL)
					{
						WORD nValue;
						MODBUS_WORD_FROM_MSG(lpRxMsgBuf, nValue);
						lpstRegisterInfo->nMsgValue = (DWORD)nValue;

						nRegAddr ++;
						nRegCount --;
					}
					else
					{
						DWORD nValue;
						MODBUS_DWORD_FROM_MSG(lpRxMsgBuf, nValue);
						lpstRegisterInfo->nMsgValue = nValue;

						nRegAddr += 2;
						if(nRegCount < 2)
						{
							bRetVal = FALSE;
							break;
						}
						else
							nRegCount -= 2;
					}
				}
				else
				{
					bRetVal = FALSE;
					break;
				}
			}
		}
		else
			bRetVal = FALSE;
	}
	return bRetVal;
}

BOOL COwnModBusMaster::ExtractErrorCodeFromReplyMsg(void)
{
	return TRUE;
}

COwnModBusMaster& COwnModBusMaster::operator=(COwnModBusMaster& clsSrcMaster)
{
	//TODO: insert return statement here
	COwnModBusDef* lpOwnThis = (COwnModBusDef*)this;
	*lpOwnThis = *((COwnModBusDef*)&clsSrcMaster);

	RemoveAllModBusAccessReadSpec(MODBUS_REG_COIL);
	RemoveAllModBusAccessReadSpec(MODBUS_REG_DISCRET);
	RemoveAllModBusAccessReadSpec(MODBUS_REG_HOLD);
	RemoveAllModBusAccessReadSpec(MODBUS_REG_INPUT);

	RemoveAllModBusAccessWriteSpec(MODBUS_REG_COIL);
	RemoveAllModBusAccessWriteSpec(MODBUS_REG_HOLD);

	CModBusAccessTypeArray* lparrayAccessTypeDst;

	//	Read Access Type;
	//	Coil
	if(clsSrcMaster.m_lparrayCoilReadType)
	{
		lparrayAccessTypeDst = GetModBusAccessReadArrayByType(MODBUS_REG_COIL);
		lparrayAccessTypeDst->Copy(*(clsSrcMaster.m_lparrayCoilReadType));
	}
	else
	{
		if(m_lparrayCoilReadType)
			delete m_lparrayCoilReadType;
		m_lparrayCoilReadType = NULL;
	}
	//	Discret
	if(clsSrcMaster.m_lparrayDiscretReadType)
	{
		lparrayAccessTypeDst = GetModBusAccessReadArrayByType(MODBUS_REG_DISCRET);
		lparrayAccessTypeDst->Copy(*(clsSrcMaster.m_lparrayDiscretReadType));
	}
	else
	{
		if(m_lparrayDiscretReadType)
			delete m_lparrayDiscretReadType;
		m_lparrayDiscretReadType = NULL;
	}
	//	Hold
	if(clsSrcMaster.m_lparrayHoldReadType)
	{
		lparrayAccessTypeDst = GetModBusAccessReadArrayByType(MODBUS_REG_HOLD);
		lparrayAccessTypeDst->Copy(*(clsSrcMaster.m_lparrayHoldReadType));
	}
	else
	{
		if(m_lparrayHoldReadType)
			delete m_lparrayHoldReadType;
		m_lparrayHoldReadType = NULL;
	}
	//	INPUT
	if(clsSrcMaster.m_lparrayInputReadType)
	{
		lparrayAccessTypeDst = GetModBusAccessReadArrayByType(MODBUS_REG_INPUT);
		lparrayAccessTypeDst->Copy(*(clsSrcMaster.m_lparrayInputReadType));
	}
	else
	{
		if(m_lparrayInputReadType)
			delete m_lparrayInputReadType;
		m_lparrayInputReadType = NULL;
	}

	//	Write Access Type;
	//	Coil
	if(clsSrcMaster.m_lparrayCoilForceType)
	{
		lparrayAccessTypeDst = GetModBusAccessWriteArrayByType(MODBUS_REG_COIL);
		lparrayAccessTypeDst->Copy(*(clsSrcMaster.m_lparrayCoilForceType));
	}
	else
	{
		if(m_lparrayCoilForceType)
			delete m_lparrayCoilForceType;
		m_lparrayCoilForceType = NULL;
	}
	//	Hold
	if(clsSrcMaster.m_lparrayHoldWriteType)
	{
		lparrayAccessTypeDst = GetModBusAccessWriteArrayByType(MODBUS_REG_HOLD);
		lparrayAccessTypeDst->Copy(*(clsSrcMaster.m_lparrayHoldWriteType));
	}
	else
	{
		if(m_lparrayHoldWriteType)
			delete m_lparrayHoldWriteType;
		m_lparrayHoldWriteType = NULL;
	}
	return *this;
}

WORD COwnModBusMaster::GetModBusAccessReadCount(MODBUS_REG_TYPE_SORT enumRegType)
{
	CModBusAccessTypeArray* lparrayAccessReadType = 
		GetModBusAccessReadArrayByType(enumRegType, FALSE);
	return (WORD)((lparrayAccessReadType == NULL) ? 0 : 
		lparrayAccessReadType->GetCount());
}

BOOL COwnModBusMaster::GetModBusAccessReadInfo(MODBUS_REG_TYPE_SORT enumRegType, WORD nAccessId, MODBUS_REGIST_ACCESS_ST& stAccessInfo)
{
	CModBusAccessTypeArray* lparrayAccessReadType = 
		GetModBusAccessReadArrayByType(enumRegType, FALSE);

	if(lparrayAccessReadType == NULL)
		return FALSE;

	if(lparrayAccessReadType->GetCount() > nAccessId)
	{
		stAccessInfo = lparrayAccessReadType->ElementAt(nAccessId);
		return TRUE;
	}
	return FALSE;
}

WORD COwnModBusMaster::GetModBusAccessWriteCount(MODBUS_REG_TYPE_SORT enumRegType)
{
	CModBusAccessTypeArray* lparrayAccessWriteType = 
		GetModBusAccessWriteArrayByType(enumRegType, FALSE);
	return (WORD)((lparrayAccessWriteType == NULL) ? 0 : 
		lparrayAccessWriteType->GetCount());
}

BOOL COwnModBusMaster::GetModBusAccessWriteInfo(MODBUS_REG_TYPE_SORT enumRegType, WORD nAccessId, MODBUS_REGIST_ACCESS_ST& stAccessInfo)
{
	CModBusAccessTypeArray* lparrayAccessWriteType = 
		GetModBusAccessWriteArrayByType(enumRegType, FALSE);

	if(lparrayAccessWriteType == NULL)
		return FALSE;

	if(lparrayAccessWriteType->GetCount() > nAccessId)
	{
		stAccessInfo = lparrayAccessWriteType->ElementAt(nAccessId);
		return TRUE;
	}
	return FALSE;
}

void COwnModBusMaster::ReadModBusAccessInfoFile(LPCTSTR lpszFilePath)
{
	CString strAppName, strKeyName;
	LPCTSTR lpszAppName;

	LPCTSTR	lpszAppPrefix[] = {_T("Coil"), _T("Discret"), _T("Hold"), _T("Input")};
	WORD nbufAccessCount[4];
	WORD nSpecAccessCount;

	lpszAppName = _T("AccessRead");
	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId ++)
	{
		strKeyName.Format(_T("Read%s"), lpszAppPrefix[nRegTypeId]);
		nbufAccessCount[nRegTypeId] = 
			::GetPrivateProfileInt(lpszAppName, strKeyName, 0, lpszFilePath);
	}

	MODBUS_REGIST_ACCESS_ST stAccessInfo;
	WORD& nStartAddr = stAccessInfo.nAddress;
	WORD& nRegCount = stAccessInfo.nCount;

	CModBusAccessTypeArray* lparrayAccessInfo;
	MODBUS_REG_TYPE_SORT enumRegTypeSort;

	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId ++)
	{
		nSpecAccessCount = nbufAccessCount[nRegTypeId];
		enumRegTypeSort = (MODBUS_REG_TYPE_SORT)nRegTypeId;
		if(nSpecAccessCount > 0)
		{
			lparrayAccessInfo = GetModBusAccessReadArrayByType(enumRegTypeSort);
			lparrayAccessInfo->RemoveAll();

			for(WORD nAccessId = 0; nAccessId < nSpecAccessCount; nAccessId ++)
			{
				strAppName.Format(_T("Read%s%d"), lpszAppPrefix[nRegTypeId], nAccessId);
				lpszAppName = (LPCTSTR)strAppName;

				nStartAddr = (WORD)::GetPrivateProfileInt(lpszAppName, _T("StartAddr"), 0, lpszFilePath);
				nRegCount = (WORD)::GetPrivateProfileInt(lpszAppName, _T("RegCount"), 0, lpszFilePath);

				lparrayAccessInfo->Add(stAccessInfo);
			}
		}
		else
		{
			lparrayAccessInfo = GetModBusAccessReadArrayByType(enumRegTypeSort, FALSE);
			if(lparrayAccessInfo)
			{
				lparrayAccessInfo->RemoveAll();
				delete lparrayAccessInfo;
				lparrayAccessInfo = NULL;
			}
		}
	}

	lpszAppName = _T("AccessWrite");
	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId += 2)
	{
		strKeyName.Format(_T("Write%s"), lpszAppPrefix[nRegTypeId]);
		nbufAccessCount[nRegTypeId] = 
			::GetPrivateProfileInt(lpszAppName, strKeyName, 0, lpszFilePath);
	}

	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId += 2)
	{
		nSpecAccessCount = nbufAccessCount[nRegTypeId];
		enumRegTypeSort = (MODBUS_REG_TYPE_SORT)nRegTypeId;
		if(nSpecAccessCount > 0)
		{
			lparrayAccessInfo = GetModBusAccessWriteArrayByType(enumRegTypeSort);
			lparrayAccessInfo->RemoveAll();

			for(WORD nAccessId = 0; nAccessId < nSpecAccessCount; nAccessId ++)
			{
				strAppName.Format(_T("Write%s%d"), lpszAppPrefix[nRegTypeId], nAccessId);
				lpszAppName = (LPCTSTR)strAppName;

				nStartAddr = (WORD)::GetPrivateProfileInt(lpszAppName, _T("StartAddr"), 0, lpszFilePath);
				nRegCount = (WORD)::GetPrivateProfileInt(lpszAppName, _T("RegCount"), 0, lpszFilePath);

				lparrayAccessInfo->Add(stAccessInfo);
			}
		}
		else
		{
			lparrayAccessInfo = GetModBusAccessWriteArrayByType(enumRegTypeSort, FALSE);
			if(lparrayAccessInfo)
			{
				lparrayAccessInfo->RemoveAll();
				delete lparrayAccessInfo;
				lparrayAccessInfo = NULL;
			}
		}
	}
}

void COwnModBusMaster::WriteModBusAccessInfoFile(LPCTSTR lpszFilePath)
{
	CString strAppName, strKeyName, strKeyVal;
	LPCTSTR lpszAppName;

	LPCTSTR	lpszAppPrefix[] = {_T("Coil"), _T("Discret"), _T("Hold"), _T("Input")};
	WORD nbufAccessCount[4];
	WORD nSpecAccessCount;

	lpszAppName = _T("AccessRead");
	nbufAccessCount[0]	= GetModBusAccessReadCount(MODBUS_REG_COIL);
	nbufAccessCount[1]	= GetModBusAccessReadCount(MODBUS_REG_DISCRET);
	nbufAccessCount[2]	= GetModBusAccessReadCount(MODBUS_REG_HOLD);
	nbufAccessCount[3]	= GetModBusAccessReadCount(MODBUS_REG_INPUT);

	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId ++)
	{
		strKeyName.Format(_T("Read%s"), lpszAppPrefix[nRegTypeId]);
		strKeyVal.Format(_T("%u"), nbufAccessCount[nRegTypeId]);

		::WritePrivateProfileString(lpszAppName, strKeyName, strKeyVal, lpszFilePath);
	}

	CModBusAccessTypeArray* lparrayAccessInfo;
	MODBUS_REG_TYPE_SORT enumRegTypeSort;

	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId ++)
	{
		nSpecAccessCount = nbufAccessCount[nRegTypeId];
		enumRegTypeSort = (MODBUS_REG_TYPE_SORT)nRegTypeId;
		if(nSpecAccessCount > 0)
		{
			lparrayAccessInfo = GetModBusAccessReadArrayByType(enumRegTypeSort);

			for(WORD nAccessId = 0; nAccessId < nSpecAccessCount; nAccessId ++)
			{
				strAppName.Format(_T("Read%s%d"), lpszAppPrefix[nRegTypeId], nAccessId);
				lpszAppName = (LPCTSTR)strAppName;

				MODBUS_REGIST_ACCESS_ST& stAccessInfo = lparrayAccessInfo->ElementAt(nAccessId);

				strKeyVal.Format(_T("%u"), stAccessInfo.nAddress);
				::WritePrivateProfileString(lpszAppName, _T("StartAddr"), strKeyVal, lpszFilePath);

				strKeyVal.Format(_T("%u"), stAccessInfo.nCount);
				::WritePrivateProfileString(lpszAppName, _T("RegCount"), strKeyVal, lpszFilePath);
			}
		}
	}

	lpszAppName = _T("AccessWrite");
	nbufAccessCount[0]	= GetModBusAccessWriteCount(MODBUS_REG_COIL);
	nbufAccessCount[2]	= GetModBusAccessWriteCount(MODBUS_REG_HOLD);
	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId += 2)
	{
		strKeyName.Format(_T("Write%s"), lpszAppPrefix[nRegTypeId]);
		strKeyVal.Format(_T("%u"), nbufAccessCount[nRegTypeId]);

		::WritePrivateProfileString(lpszAppName, strKeyName, strKeyVal, lpszFilePath);
	}

	for(WORD nRegTypeId = 0; nRegTypeId < 4; nRegTypeId += 2)
	{
		nSpecAccessCount = nbufAccessCount[nRegTypeId];
		enumRegTypeSort = (MODBUS_REG_TYPE_SORT)nRegTypeId;
		if(nSpecAccessCount > 0)
		{
			lparrayAccessInfo = GetModBusAccessWriteArrayByType(enumRegTypeSort);

			for(WORD nAccessId = 0; nAccessId < nSpecAccessCount; nAccessId ++)
			{
				strAppName.Format(_T("Write%s%d"), lpszAppPrefix[nRegTypeId], nAccessId);
				lpszAppName = (LPCTSTR)strAppName;

				MODBUS_REGIST_ACCESS_ST& stAccessInfo = lparrayAccessInfo->ElementAt(nAccessId);

				strKeyVal.Format(_T("%u"), stAccessInfo.nAddress);
				::WritePrivateProfileString(lpszAppName, _T("StartAddr"), strKeyVal, lpszFilePath);

				strKeyVal.Format(_T("%u"), stAccessInfo.nCount);
				::WritePrivateProfileString(lpszAppName, _T("RegCount"), strKeyVal, lpszFilePath);
			}
		}
	}
}

WORD COwnModBusMaster::GetModBusAccessReadTotalCount(void)
{
	WORD nAccessReadCount = GetModBusAccessReadCount(MODBUS_REG_COIL);
	nAccessReadCount += GetModBusAccessReadCount(MODBUS_REG_DISCRET);
	nAccessReadCount += GetModBusAccessReadCount(MODBUS_REG_HOLD);
	nAccessReadCount += GetModBusAccessReadCount(MODBUS_REG_INPUT);
	return nAccessReadCount;
}

BOOL COwnModBusMaster::GetModBusAccessReadTypeFirst(MODBUS_REG_TYPE_SORT& enumRegSortType, WORD& nAccessId)
{
	WORD nAccessCount = GetModBusAccessReadCount(MODBUS_REG_COIL);

	m_stModBusAccessReadState.nAccessId = 0;
	BOOL bRetVal = FALSE;
	for(int nRegSortId = 0; nRegSortId < 4; nRegSortId ++)
	{
		MODBUS_REG_TYPE_SORT enumChkRegSortType = (MODBUS_REG_TYPE_SORT)nRegSortId;
		nAccessCount = GetModBusAccessReadCount(enumChkRegSortType);
		if(nAccessCount > 0)
		{
			enumRegSortType = enumChkRegSortType;
			bRetVal = TRUE;
			break;
		}
	}

	if(bRetVal)
	{
		m_stModBusAccessReadState.enumRegSortType = enumRegSortType;
		nAccessId = 0;
	}
	return bRetVal;
}

BOOL COwnModBusMaster::GetModBusAccessReadTypeNext(MODBUS_REG_TYPE_SORT& enumRegSortType, WORD& nAccessId)
{
	WORD nGetAccessId = m_stModBusAccessReadState.nAccessId;
	WORD nGetAccessAmount;
	BOOL bRetVal = FALSE;

	nGetAccessId ++;

	for(WORD nChkSortId = m_stModBusAccessReadState.enumRegSortType; nChkSortId < 4; nChkSortId ++)
	{
		MODBUS_REG_TYPE_SORT enumChkRegType = (MODBUS_REG_TYPE_SORT)nChkSortId;
		nGetAccessAmount = GetModBusAccessReadCount(enumChkRegType);

		if(nGetAccessAmount > 0)
		{
			if(nGetAccessId < nGetAccessAmount)
			{
				enumRegSortType = enumChkRegType;
				nAccessId = nGetAccessId;
				bRetVal = TRUE;
				break;
			}
		}
		nGetAccessId = 0;
	}

	if(bRetVal == TRUE)
	{
		m_stModBusAccessReadState.enumRegSortType = enumRegSortType;
		m_stModBusAccessReadState.nAccessId = nAccessId;
	}

	return bRetVal;
}

void COwnModBusMaster::SetModBusAccessSuccess(BOOL bSuccess)
{
	m_boolDeviceLinkFlag = bSuccess;
}

BOOL COwnModBusMaster::GetModBusAccessSuccess(void)
{
	return m_boolDeviceLinkFlag;
}
