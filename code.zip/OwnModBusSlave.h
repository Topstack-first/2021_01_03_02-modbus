#pragma once

#include "OwnModBusDef.h"

class COwnModBusSlave : public COwnModBusDef
{
public:
	COwnModBusSlave(void);
	~COwnModBusSlave(void);

protected:
	BOOL ParseRequestMsgGetCommandType(void);
	BOOL ParseRequestMsgParsingFunction(void);
	BOOL ParseRequestMsgWaitEndChar(void);
	BOOL ParseRequestMsgExtractData(void);
	BOOL ExtractPresetDataFromRequestMsg(void);
	BOOL ExtractReadDataFromRequestMsg(void);
public:
	BOOL ParseRequestMessage(char* lpRequestMsg, WORD nRxLen);
protected:

public:
	WORD ConstructReplyMessage(char* lpDstMsg, WORD nBufLen = MODBUS_MESSAGE_MAX_LEN);

	WORD ConstructReplyMsgBody(void);
	WORD ConstructReplyMsgWriteRegister(void);
	WORD ConstructReplyMsgReadRegister(void);
	COwnModBusSlave& operator=(COwnModBusSlave& clsSrcSlave);
protected:
	WORD ConstructReplyMsgErrorState(void);
};
