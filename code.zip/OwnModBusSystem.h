#pragma once

#include "OwnModBusMaster.h"
#include "OwnModBusSlave.h"

typedef struct tagMODBUS_SYSTEM_DEVICE_ST
{
	CString strDeviceName;
	BOOL bSlaveDev;
	WORD nSeriesId;
	CString strSeriesName;

	COwnModBusDef* lpclsModBusInfo;
}MODBUS_SYSTEM_DEVICE_ST;

typedef CArray<MODBUS_SYSTEM_DEVICE_ST, MODBUS_SYSTEM_DEVICE_ST> CModBusSysDevArray;
typedef CArray<COwnModBusDef*, COwnModBusDef*>			CModBusDefsPtrArray;

class COwnModBusSystem
{
public:
	COwnModBusSystem(void);
	~COwnModBusSystem(void);

protected:
	CModBusSysDevArray		m_arrayModBusSysDev;
	CModBusDefsPtrArray		m_arrayModBusDefsPtr;

public:
	WORD GetModBusSeriesCount(void);
	COwnModBusDef* GetModBusSereisInfoPtr(WORD nSeriesId);
	void RemoveAllModBusSeriesInfo(void);
	WORD AppenModBusSeriesInfo(COwnModBusDef* lpclsModBusSeries);
	WORD GetModBusDeviceInfoCount(void);
	MODBUS_SYSTEM_DEVICE_ST* GetModBusDeviceInfoPtr(WORD nDevId);
	WORD AppendModBusDeviceBaseInfo(WORD nSeriesId, BOOL bIsSlave, LPCTSTR lpszDevName);
	void RemoveAtModBusDeviceInfo(WORD nDeviceId);
	WORD InsertAtModBusDeviceBaseInfo(WORD nInsertId, WORD nSeriesId, BOOL bIsSlave, LPCTSTR lpszDevName);
	BOOL ExchangeModBusDeviceInfoPostion(int nPosition1st, int nPosition2nd);
	COwnModBusSystem& operator=(COwnModBusSystem& clsModBusSysSrc);
	void RemoveAllModBusDeviceInfo(void);

	BOOL ReadModBusSystemConfigFile(LPCTSTR lpszConfPath);
	BOOL ReadModBusSeriesInfoFile(LPCTSTR lpszConfPath);
	BOOL ReadModBusDeviceInfoFile(LPCTSTR lpszConfPath);

	BOOL WriteModBusSystemConfigFile(LPCTSTR lpszConfPath);
	BOOL WriteModBusSeriesInfoFile(LPCTSTR lpszConfPath);
	BOOL WriteModBusDeviceInfoFile(LPCTSTR lpszConfPath);
};
