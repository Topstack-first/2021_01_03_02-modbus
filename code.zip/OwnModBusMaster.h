#pragma once
#include "OwnModBusDef.h"

typedef struct tagMODBUS_REGIST_ACCESS_ST
{
	WORD nAddress;
	WORD nCount;
}MODBUS_REGIST_ACCESS_ST;
typedef CArray<MODBUS_REGIST_ACCESS_ST, MODBUS_REGIST_ACCESS_ST> CModBusAccessTypeArray;


class COwnModBusMaster : public COwnModBusDef
{
public:
	COwnModBusMaster(void);
	~COwnModBusMaster(void);

protected:

	//	ModBus Access Method Type
	CModBusAccessTypeArray* m_lparrayCoilReadType;
	CModBusAccessTypeArray* m_lparrayCoilForceType;

	CModBusAccessTypeArray* m_lparrayDiscretReadType;

	CModBusAccessTypeArray* m_lparrayHoldReadType;
	CModBusAccessTypeArray* m_lparrayHoldWriteType;

	CModBusAccessTypeArray*	m_lparrayInputReadType;

	typedef struct tagMODBUS_ACCESS_SET_STATE_ST
	{
		MODBUS_REG_TYPE_SORT enumRegSortType;
		WORD nAccessId;
	}MODBUS_ACCESS_SET_STATE_ST;

	MODBUS_ACCESS_SET_STATE_ST m_stModBusAccessReadState;
	MODBUS_ACCESS_SET_STATE_ST m_stModBusAccessWriteState;

protected:
	MODBUS_REGIST_ACCESS_ST* GetAccessRegistPointerFromArray(
		CModBusAccessTypeArray* lpRegAccessInfoArray, WORD nOrder);
	CModBusAccessTypeArray* GetModBusAccessReadArrayByType(
		MODBUS_REG_TYPE_SORT enumRegType, BOOL bCreate = TRUE);
	CModBusAccessTypeArray* GetModBusAccessWriteArrayByType(
		MODBUS_REG_TYPE_SORT enumRegType, BOOL bCreate = TRUE);

public:
	WORD AppendModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAddr, WORD nCount);
	WORD InsertAtModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nInsertPos, WORD nAddr, WORD nCount);
	void RemoveAtModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nRemovePos);
	void RemoveAllModBusAccessReadSpec(MODBUS_REG_TYPE_SORT enumRegType);

	WORD AppendModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAddr, WORD nCount);
	WORD InsertAtModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nInsertPos, WORD nAddr, WORD nCount);
	void RemoveAtModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nRemovePos);
	void RemoveAllModBusAccessWriteSpec(MODBUS_REG_TYPE_SORT enumRegType);

public:

	BOOL ParseReplyMessage(char* lpReplyMsg, WORD nRxLen);

protected:
	BOOL ParseReplyMsgCheckCommandType(void);
	BOOL ParseReplyMsgParsingFunction(void);
	BOOL ParseReplyMsgWaitEndChar(void);
	BOOL ParseReplyMsgExtractData(void);
	BOOL ExtractPresetDataFromReplyMsg(void);
	BOOL ExtractReadDataFromReplyMsg(void);
public:
	WORD ConstructRequestMessageReadIndirect(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAccessId, char* lpDstMsg, WORD nBufLen = MODBUS_MESSAGE_MAX_LEN);
	WORD ConstructRequestMessageReadDirect(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAddress, WORD nCount, char* lpDstMsg, WORD nBufLen = MODBUS_MESSAGE_MAX_LEN);
	WORD ConstructRequestMessageWriteIndirect(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAccessId, char* lpDstMsg, WORD nBufLen = MODBUS_MESSAGE_MAX_LEN);
	WORD ConstructRequestMessageWriteDirect(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAddress, WORD nCount, char* lpDstMsg, WORD nBufLen = MODBUS_MESSAGE_MAX_LEN);
	WORD ConstructRequestMessageWriteSingle(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAddress, char* lpDstMsg, WORD nBufLen = MODBUS_MESSAGE_MAX_LEN);
	COwnModBusMaster& operator=(COwnModBusMaster& clsSrcMaster);

	WORD GetModBusAccessReadCount(MODBUS_REG_TYPE_SORT enumRegType);
	BOOL GetModBusAccessReadInfo(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAccessId, MODBUS_REGIST_ACCESS_ST& stAccessInfo);
	WORD GetModBusAccessWriteCount(MODBUS_REG_TYPE_SORT enumRegType);
	BOOL GetModBusAccessWriteInfo(MODBUS_REG_TYPE_SORT enumRegType, 
		WORD nAccessId, MODBUS_REGIST_ACCESS_ST& stAccessInfo);
	void ReadModBusAccessInfoFile(LPCTSTR lpszFilePath);
	void WriteModBusAccessInfoFile(LPCTSTR lpszFilePath);

	WORD GetModBusAccessReadTotalCount(void);
	BOOL GetModBusAccessReadTypeFirst(
		MODBUS_REG_TYPE_SORT& enumRegSortType, WORD& nAccessId);
	BOOL GetModBusAccessReadTypeNext(MODBUS_REG_TYPE_SORT& enumRegSortType, WORD& nAccessId);
protected:
	BOOL ExtractErrorCodeFromReplyMsg(void);
	BOOL m_boolDeviceLinkFlag;
public:
	void SetModBusAccessSuccess(BOOL bSuccess);
	BOOL GetModBusAccessSuccess(void);
};
